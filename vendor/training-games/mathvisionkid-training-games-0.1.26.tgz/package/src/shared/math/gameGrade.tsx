import React, { createContext, useContext, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useEmbeddedTraining } from '../integration/context';

export type Grade = 1 | 2 | 3 | 4 | 5;
const GradeContext = createContext<Grade>(5);
export const useGameGrade = () => useContext(GradeContext);
export const GAME_GRADES = {
  'race-to-finish': [1, 2, 3, 4, 5],
  'terrain-racing': [2, 3, 4, 5],
  'energy-defense': [1, 2, 3, 4, 5],
} as const;
type GradedGame = keyof typeof GAME_GRADES;
const TITLES: Record<GradedGame, string> = {
  'race-to-finish': 'Đua Về Đích', 'terrain-racing': 'Siêu Xe Vượt Địa Hình', 'energy-defense': 'Thủ Thành Năng Lượng',
};
const TOPICS: Record<GradedGame, Partial<Record<Grade, string>>> = {
  'race-to-finish': { 1: 'Cộng, trừ trong 100, không nhớ', 2: 'Cộng, trừ có nhớ; bảng nhân, chia 2 và 5', 3: 'Bốn phép tính; bảng nhân, chia 2–9', 4: 'Số tự nhiên lớn và phân số', 5: 'Phân số, số thập phân, hình học và toán tổng hợp' },
  'terrain-racing': { 2: 'Chia trong bảng 2 và 5', 3: 'Chia trong các bảng 2–9', 4: 'Chia cho số có hai chữ số', 5: 'Tính vận tốc từ quãng đường và thời gian' },
  'energy-defense': { 1: 'Cộng trong 100, không nhớ', 2: 'Cộng có nhớ trong 20, 100 và 1000', 3: 'Cộng đến 5 chữ số, có nhớ nhiều lượt; tổng ba số', 4: 'Cộng phân số cùng mẫu và khác mẫu', 5: 'Cộng số thập phân, hỗn số và ôn tập tổng hợp' },
};
export function gradeTopic(game: GradedGame, grade: Grade) { return TOPICS[game][grade] ?? ''; }

/** The game mounts only after confirmation; changing grade creates a fresh run. */
export function withGradeSelection(game: GradedGame, Screen: React.ComponentType<{ onExit: () => void }>) {
  return function GradeSelection({ onExit }: { onExit: () => void }) {
    const profileGrade = useEmbeddedTraining()?.gradeLevel;
    const [draft, setDraft] = useState<Grade | null>(null);
    const [grade, setGrade] = useState<Grade | null>(null);
    const activeGrade = profileGrade ?? grade;
    if (activeGrade) return <GradeContext.Provider value={activeGrade}><Screen key={activeGrade} onExit={onExit} /></GradeContext.Provider>;
    return <ScrollView testID={`grade-selection-${game}`} contentContainerStyle={s.page}>
      <View style={s.card}>
        <Text accessibilityRole="header" style={s.title}>{TITLES[game]}</Text>
        <Text style={s.copy}>Khuyến nghị: lớp {GAME_GRADES[game][0]}–5. Chọn lớp để nhận câu hỏi vừa sức với em.</Text>
        <View accessibilityLabel="Chọn lớp" style={s.grades}>
          {GAME_GRADES[game].map(value => <Pressable key={value} accessibilityRole="button" accessibilityLabel={`Lớp ${value}`}
            accessibilityState={{ selected: draft === value }} aria-pressed={draft === value} testID={`game-grade-${value}`} onPress={() => setDraft(value)}
            style={({ pressed }) => [s.grade, draft === value && s.selected, pressed && s.pressed]}>
            <Text style={[s.label, draft === value && s.selectedLabel]}>Lớp {value}{draft === value ? ' ✓' : ''}</Text>
          </Pressable>)}
        </View>
        <Text accessibilityLiveRegion="polite" style={s.topic}>{draft ? gradeTopic(game, draft) : 'Em hãy chọn lớp trước khi bắt đầu nhé.'}</Text>
        <Pressable accessibilityRole="button" accessibilityLabel="Bắt đầu với lớp đã chọn" accessibilityState={{ disabled: !draft }} disabled={!draft}
          testID="game-grade-start" onPress={() => { if (draft) setGrade(draft); }} style={({ pressed }) => [s.start, !draft && s.disabled, pressed && s.pressed]}>
          <Text style={s.startText}>Bắt đầu{draft ? ` · Lớp ${draft}` : ''}</Text>
        </Pressable>
        <Text style={s.copy}>Muốn đổi lớp, em về khu trò chơi rồi mở lại trò nhé.</Text>
        <Pressable accessibilityRole="button" onPress={onExit} style={s.back}><Text style={s.label}>Về khu trò chơi</Text></Pressable>
      </View>
    </ScrollView>;
  };
}
const s = StyleSheet.create({
  page: { flexGrow: 1, justifyContent: 'center', padding: 24, backgroundColor: '#F5F3FF' },
  card: { width: '100%', maxWidth: 620, alignSelf: 'center', padding: 24, gap: 20, borderRadius: 24, backgroundColor: '#FFFFFF' },
  title: { fontSize: 26, fontWeight: '800', color: '#282044' }, copy: { fontSize: 15, lineHeight: 23, color: '#514766' },
  grades: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  grade: { minWidth: 88, minHeight: 52, padding: 14, borderRadius: 14, borderWidth: 2, borderColor: '#C8BEDD', alignItems: 'center', justifyContent: 'center' },
  selected: { backgroundColor: '#5B3AB1', borderColor: '#5B3AB1' }, label: { fontSize: 16, fontWeight: '700', color: '#423258' },
  selectedLabel: { color: '#FFFFFF' }, topic: { fontSize: 16, lineHeight: 24, color: '#423258', minHeight: 48 },
  start: { minHeight: 52, padding: 14, borderRadius: 14, backgroundColor: '#5B3AB1', alignItems: 'center', justifyContent: 'center' },
  startText: { fontSize: 17, fontWeight: '800', color: '#FFFFFF' }, disabled: { opacity: 0.45 }, pressed: { opacity: 0.75 },
  back: { minHeight: 48, alignItems: 'center', justifyContent: 'center' },
});
