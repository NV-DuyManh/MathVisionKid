import type { Grade } from '../../../shared/math/gameGrade';
import { rational, add, subtract, multiply, divide, formatAnswer } from './exactAnswer';
import type { Calculation, RaceQuestion } from './questions';

const banks = new Map<Grade, readonly RaceQuestion[]>();
/** Finite, verified mathematical variants. Commutative duplicates are removed. */
export function gradeRaceBank(grade: Grade): readonly RaceQuestion[] {
  if (grade === 5) throw new Error('Grade 5 uses the original generator');
  const cached = banks.get(grade); if (cached) return cached;
  const rows: RaceQuestion[] = [], seen = new Set<string>();
  const put = (op: '+' | '−' | '×' | '÷', a: number, b: number, den = 1, db = den) => {
    const left = rational(a, den), right = rational(b, db);
    const terms = [formatAnswer(left), formatAnswer(right)];
    if (op === '+' || op === '×') terms.sort();
    const key = `${op}:${terms.join(':')}`; if (seen.has(key)) return; seen.add(key);
    const answer = op === '+' ? add(left, right) : op === '−' ? subtract(left, right) : op === '×' ? multiply(left, right) : divide(left, right);
    const calculation: Calculation = { op, left, right };
    const expression = `${formatAnswer(left)} ${op} ${formatAnswer(right)}`;
    rows.push({ key: `grade${grade}-${rows.length}`, difficulty: 'medium', category: den === 1 && db === 1 ? `grade${grade}-natural` : `grade${grade}-fraction`,
      prompt: `Tính: ${expression}`, answer, calculation, explanation: `${expression} = ${formatAnswer(answer)}.` });
  };
  if (grade === 1) {
    for (let a = 1; a < 100; a++) for (let b = 1; b <= a; b++) {
      if (a + b < 100 && a % 10 + b % 10 < 10) put('+', a, b);
      if (a % 10 >= b % 10) put('−', a, b);
    }
  } else {
    const scale = grade === 2 ? 1 : grade === 3 ? 10 : 137;
    for (let a = 11; a <= 99; a++) for (let b = 1; b <= 29; b++) {
      if (grade !== 2 || a + b < 100) put('+', a * scale, b * scale + (grade > 2 ? 7 : 0));
      put('−', a * scale, Math.min(a * scale, b * scale));
    }
    for (const table of grade === 2 ? [2, 5] : [2, 3, 4, 5, 6, 7, 8, 9]) for (let n = 1; n <= (grade === 2 ? 10 : 99); n++) {
      put('×', n, table); put('÷', n * table, table);
    }
    if (grade === 4) for (let da = 2; da <= 12; da++) for (let db = 2; db <= 12; db++)
      for (let a = 1; a < da; a++) for (let b = 1; b < db; b++) put('+', a, b, da, db);
  }
  banks.set(grade, rows); return rows;
}
