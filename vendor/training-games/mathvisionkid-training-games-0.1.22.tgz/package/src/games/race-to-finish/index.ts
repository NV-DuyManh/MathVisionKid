import { RaceToFinishScreen as Screen } from './screens/RaceToFinishScreen';
import { withGradeSelection } from '../../shared/math/gameGrade';
export const RaceToFinishScreen = withGradeSelection('race-to-finish', Screen);
export * from './types/index';
