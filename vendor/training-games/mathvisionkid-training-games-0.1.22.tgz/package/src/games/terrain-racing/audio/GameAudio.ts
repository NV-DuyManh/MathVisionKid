import type { Phase } from '../types';

export type SoundName = 'engine' | 'siren' | 'accelerate' | 'landslide' | 'jump' | 'landing' | 'impact' | 'select' | 'victory' | 'loss';
export interface PlayerPort {
  loop: boolean;
  volume: number;
  playing: boolean;
  play(): void;
  pause(): void;
  seekTo(seconds: number): Promise<void>;
  remove(): void;
  setPlaybackRate?(rate: number): void;
}

/** Session-owned players. Never toggles the shared/global sound manager. */
export class GameAudio {
  private enabled = false;
  private suspended = false;
  private disposed = false;
  private phase: Phase = 'chase';
  private activated = false;
  private tokens: Partial<Record<SoundName, number>> = {};
  private generation = 0;
  public error: string | null = null;
  constructor(private players: Record<SoundName, PlayerPort>) {
    players.engine.loop = true; players.siren.loop = true;
    // Relative levels live in the WAVs because Safari on iOS ignores .volume.
    // Do not attenuate those already balanced files a second time on native.
    for (const player of Object.values(players)) player.volume = 1;
  }
  private attempt(action: () => void) {
    try { action(); } catch(error) { this.error=String(error); }
  }
  activate() {
    if (this.disposed) return;
    this.activated = true;
    this.syncLoops();
  }
  setEnabled(enabled: boolean, userGesture = true) {
    if(this.disposed)return;
    this.enabled=enabled;
    if (userGesture) this.activated = true;
    if(!enabled){this.generation++;this.pauseAll();}
    else this.syncLoops();
  }
  setSuspended(value: boolean) {
    if(this.disposed||value===this.suspended)return;
    this.suspended=value;
    if(value){
      this.generation++;
      this.pauseAll();
    } else if(this.enabled) {
      // Resume only current ambience. A stale jump/collision/win is not replayed.
      this.syncLoops();
    }
  }
  setPhase(phase: Phase, incorrect = false) {
    if(this.disposed)return;
    if(this.phase===phase)return;
    this.phase=phase;
    // A new phase cannot leave the previous one-shot sounding over it.
    for (const name of Object.keys(this.players) as SoundName[]) {
      if (name !== 'engine' && name !== 'siren' && name !== 'select') {
        this.tokens[name] = (this.tokens[name] || 0) + 1;
        this.attempt(() => this.players[name].pause());
      }
    }
    this.syncLoops();
    const event: Partial<Record<Phase,SoundName>>={collapse:'landslide',launch:'accelerate',
      jump:'jump',policeLaunch:'accelerate',policeJump:'jump',policeRoll:'impact',result:'loss',victory:'victory'};
    if(phase==='impact')this.play(incorrect ? 'impact' : 'landing');
    else if(phase==='transition')this.play('landing');
    else if(event[phase])this.play(event[phase]!);
  }
  play(name: SoundName) {
    if(!this.enabled||!this.activated||this.suspended||this.disposed)return;
    const generation=this.generation,token=(this.tokens[name]||0)+1;
    this.tokens[name]=token;
    this.attempt(()=>{
      const player=this.players[name];
      player.pause();
      void player.seekTo(0).then(()=>{
        if(!this.disposed&&this.enabled&&!this.suspended&&this.generation===generation&&this.tokens[name]===token){
          this.attempt(()=>player.play());
        }
      }).catch(error=>{this.error=String(error);});
    });
  }
  private syncLoops() {
    const running=this.enabled&&this.activated&&!this.suspended&&!this.disposed&&
      !['question','settle','result','victory'].includes(this.phase);
    this.players.engine.volume = ['jump','policeJump'].includes(this.phase) ? .13 / .24 : 1;
    this.attempt(() => this.players.engine.setPlaybackRate?.(['launch','policeLaunch','escape'].includes(this.phase) ? 1.2 : 1));
    for(const name of ['engine','siren'] as const){
      this.attempt(()=>{
        if(running&&(name!=='siren'||!['escape','policeRoll'].includes(this.phase))) {
          if (!this.players[name].playing) this.players[name].play();
        }
        else this.players[name].pause();
      });
    }
  }
  private pauseAll(){for(const player of Object.values(this.players))this.attempt(()=>player.pause());}
  replay(){
    if(this.disposed)return;
    this.generation++;this.suspended=false;this.phase='chase';this.pauseAll();
    for(const player of Object.values(this.players))void player.seekTo(0).catch(error=>{this.error=String(error);});
    this.syncLoops();
  }
  dispose(){
    if(this.disposed)return;
    this.disposed=true;this.generation++;this.pauseAll();
    for(const player of Object.values(this.players))this.attempt(()=>player.remove());
  }
}
