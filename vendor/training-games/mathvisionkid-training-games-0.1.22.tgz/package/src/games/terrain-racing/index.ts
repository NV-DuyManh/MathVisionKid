import { TerrainRacingScreen as Screen } from './screens/TerrainRacingScreen';
import { withGradeSelection } from '../../shared/math/gameGrade';
export const TerrainRacingScreen = withGradeSelection('terrain-racing', Screen);
