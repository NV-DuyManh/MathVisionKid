import { QuestionSession, questionHistory, type QuestionHistory } from '../../../shared/math/questionHistory';
import type { Grade } from '../../../shared/math/gameGrade';
import { QUESTIONS } from './questions';
import type { SpeedQuestion } from '../types';

// Distance/time only occur in the educational panel. Simulation reads the five
// fixed targets from QUESTIONS, never these variable distances or durations.
export const TERRAIN_TIME_BOUNDS={min:2,max:241} as const;
export const TERRAIN_VARIANTS_PER_STAGE=240;
export function terrainFingerprint(q:SpeedQuestion){return q.grade && q.grade < 5 ? `grade${q.grade}:divide:${q.distance}/${q.time}` : `speed:${q.stage}:divide:${q.distance}/${q.time}:m:s`;}
export function validateTerrainQuestion(q:SpeedQuestion){
  if (q.grade && q.grade < 5) return q.distance === q.time*q.correct_speed && Number.isSafeInteger(q.correct_speed) && q.correct_speed >= 1 &&
    (q.grade === 2 ? [2,5].includes(q.time) && q.correct_speed <= 10 : q.grade === 3 ? q.time >= 2 && q.time <= 9 && q.correct_speed <= 10 : q.time >= 10 && q.time <= 99 && q.correct_speed <= 99) &&
    q.sample_choices.length === 4 && new Set(q.sample_choices).size === 4 && q.sample_choices.includes(q.correct_speed);
  const base=QUESTIONS[q.stage-1];return !!base&&Number.isSafeInteger(q.time)&&q.time>=2&&q.time<=241&&
    Number.isSafeInteger(q.distance)&&q.distance===base.correct_speed*q.time&&q.correct_speed===base.correct_speed&&
    q.sample_choices.length===4&&new Set(q.sample_choices).size===4&&
    q.sample_choices.every(v=>base.sample_choices.includes(v))&&q.sample_choices.filter(v=>v===q.correct_speed).length===1&&
    q.sample_choices.some(v=>v<q.correct_speed)&&q.sample_choices.some(v=>v>q.correct_speed);
}
export class TerrainQuestions {
  private cache=new Map<number,SpeedQuestion>();
  private sessions=new Map<number,QuestionSession>();
  lastFallback=false;
  constructor(private rng:()=>number=Math.random,private history:QuestionHistory=questionHistory, private grade: Grade = 5){
    if (grade === 1) throw new Error('Terrain racing requires grade 2–5');
  }
  reset(){this.cache.clear();this.sessions.clear();}
  forStage(stage:number):SpeedQuestion{
    if(!Number.isInteger(stage)||stage<1||stage>5)throw Error('Invalid terrain stage');
    const cached=this.cache.get(stage);if(cached)return cached;
    if (this.grade < 5) {
      const session = new QuestionSession(this.history, 'terrain:grade'+this.grade);
      const pool = terrainGradeBank(this.grade as 2|3|4).map(q => ({...q, stage}));
      const eligible = pool.filter(q => session.allows(terrainFingerprint(q)));
      const recent = this.history.recent(session.group);
      const q = eligible.length ? eligible[Math.floor(this.rng()*eligible.length)] : pool.sort((a,b) => recent.indexOf(terrainFingerprint(a))-recent.indexOf(terrainFingerprint(b)))[0];
      q.sample_choices = [q.correct_speed, q.correct_speed-1, q.correct_speed+1, q.correct_speed+2];
      for (let i=3;i>0;i--) { const j=Math.floor(this.rng()*(i+1)); [q.sample_choices[i],q.sample_choices[j]]=[q.sample_choices[j],q.sample_choices[i]]; }
      if (!validateTerrainQuestion(q)) throw new Error('Invalid grade division question');
      session.accept(terrainFingerprint(q)); this.cache.set(stage,q); return q;
    }
    const base=QUESTIONS[stage-1],session=new QuestionSession(this.history,'terrain:stage'+stage);this.sessions.set(stage,session);
    const make=(time:number):SpeedQuestion=>({...base,time,distance:base.correct_speed*time,sample_choices:[...base.sample_choices]});
    let q:SpeedQuestion|undefined;this.lastFallback=false;
    for(let i=0;i<24;i++){const candidate=make(2+Math.floor(this.rng()*240));if(session.allows(terrainFingerprint(candidate))){q=candidate;break;}}
    if(!q){this.lastFallback=true;
      for(let t=2;t<=241;t++){const candidate=make(t);if(session.allows(terrainFingerprint(candidate))){q=candidate;break;}}
    }
    if(!q){const oldest=this.history.recent(session.group)[0];
      q=Array.from({length:240},(_,i)=>make(i+2)).find(c=>terrainFingerprint(c)===oldest)??make(2);
    }
    for(let i=3;i>0;i--){const j=Math.floor(this.rng()*(i+1));[q.sample_choices[i],q.sample_choices[j]]=[q.sample_choices[j],q.sample_choices[i]];}
    if(!validateTerrainQuestion(q))throw Error('Invalid generated speed question');
    session.accept(terrainFingerprint(q));this.cache.set(stage,q);return q;
  }
}

const gradeBanks = new Map<number, readonly SpeedQuestion[]>();
export function terrainGradeBank(grade: 2|3|4): readonly SpeedQuestion[] {
  const cached=gradeBanks.get(grade); if(cached)return cached;
  const rows: SpeedQuestion[]=[];
  const divisors=grade===2?[2,5]:Array.from({length:grade===3?8:90},(_,i)=>i+(grade===3?2:10));
  for(const time of divisors)for(let speed=1;speed<=(grade===4?99:10);speed++)rows.push({grade,stage:1,time,distance:time*speed,correct_speed:speed,sample_choices:[speed,speed-1,speed+1,speed+2]});
  gradeBanks.set(grade,rows);return rows;
}
