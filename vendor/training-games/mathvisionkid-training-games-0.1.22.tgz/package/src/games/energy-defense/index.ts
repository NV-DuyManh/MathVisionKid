import { EnergyDefenseScreen as Screen } from './screens/EnergyDefenseScreen';
import { withGradeSelection } from '../../shared/math/gameGrade';
export const EnergyDefenseScreen = withGradeSelection('energy-defense', Screen);
