# @mathvisionkid/training-games

Canonical implementation lives in the game repository's `src/games` and `src/shared`.
This manifest is a distribution recipe, not a second gameplay source tree.

Run `node scripts/pack-training-games.cjs --out <artifact-directory>` from this repository.
The builder walks the five public entry points' static source/asset graph, validates
the allowlist, and creates a versioned npm tarball plus SHA-256 manifest. It includes
current working files, including untracked Planet Rescue implementation files.
Tests, other games, Expo app routes/lobby, references, secrets, node_modules and
archives are excluded. No symlinks or absolute paths occur in package metadata.

Consumers install the tarball with a relative `file:` dependency. All native modules
are peers supplied by the host. Use `TrainingServicesContext` with an immutable UUID,
`ScopedGameStorage`, per-mount services and `TrainingSessionBridge` before mounting
one of the public game entries. Never pass authentication tokens to a game.

Results are versioned and local-only. Scores retain each game's original scale.
Missing metrics stay absent. Race learner metrics count only the first human seat,
excluding bots and additional local guests. Endless Defense is a separate session
with its own score/time; cumulative normal-mode answer counts are not reused.
