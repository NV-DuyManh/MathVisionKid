import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { RaceController } from '../state/RaceController';
import { useTrainingServices, useTrainingSession } from '../../../shared/integration/context';

export function useRaceGame() {
  const { profileManager, profileId, soundManager, questionHistory } = useTrainingServices();
  const [controller] = useState(() => new RaceController(undefined, questionHistory));
  const state = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
  const startedAt = state.startedAt;
  const savedSession = useRef(0);
  const [saveFailure, setSaveFailure] = useState<{ sessionId: number; message: string } | null>(null);
  useEffect(() => {
    controller.connect();
    return controller.disconnect;
  }, [controller]);
  useEffect(() => {
    if (state.gamePhase === 'evaluating_answer') {
      if (state.answerCorrect) soundManager.playCorrect(); else soundManager.playIncorrect();
    } else if (state.motion) soundManager.playTap();
  }, [state.actionId, state.gamePhase, state.answerCorrect, state.motion, soundManager]);
  useEffect(() => {
    if (!state.winner || savedSession.current === state.sessionId) return;
    savedSession.current = state.sessionId;
    soundManager.playVictory();
    void profileManager.saveSessionResult({
      sessionId: `rtf-${startedAt}-${state.sessionId}`, gameId: 'race-to-finish',
      profileId, difficulty: 'medium',
      startedAt: new Date(startedAt).toISOString(), completedAt: new Date().toISOString(),
      actualPlaytimeSeconds: Math.max(1, Math.round(controller.getActivePlaytime() / 1000)),
      isWon: state.winner.id === state.players.find(player => !player.isBot)?.id, score: controller.getLearnerCounts().correct,
      maxScore: controller.getLearnerCounts().correct + controller.getLearnerCounts().incorrect,
      correctCount: controller.getLearnerCounts().correct, incorrectCount: controller.getLearnerCounts().incorrect,
      skillsPracticed: ['Toán lớp 5', 'Chiến thuật đường tắt', 'Đếm bước tiến lùi'], schemaVersion: 2,
    }).catch(() => setSaveFailure({ sessionId: state.sessionId, message: 'Chưa lưu được kết quả trên thiết bị.' }));
  }, [state.winner, state.sessionId, state.correctCount, state.incorrectCount, startedAt, controller, profileId, profileManager, soundManager, state.players]);
  const counts = controller.getLearnerCounts();
  useTrainingSession({ attemptId: `${startedAt}-${state.sessionId}`, started: state.gamePhase !== 'setup', paused: state.isPaused,
    mode: state.gameMode, difficulty: 'medium', status: state.winner ? state.winner.id === state.players.find(player => !player.isBot)?.id ? 'won' : 'lost' : undefined,
    playtimeSeconds: controller.getActivePlaytime() / 1000, score: counts.correct, maxScore: counts.correct + counts.incorrect,
    correctCount: counts.correct, incorrectCount: counts.incorrect, skillsPracticed: ['Toán lớp 5', 'Đếm bước', 'Chiến thuật đường tắt'] });
  return {
    ...state, saveError: saveFailure?.sessionId === state.sessionId ? saveFailure.message : null,
    activePlayer: state.players[state.activePlayerIndex] || null,
    setIsPaused: (paused: boolean) => controller.send({ type: 'PAUSE', paused }),
    startGame: controller.startGame, handleRollDice: () => controller.roll(state.actionId),
    handleAnswer: (answer: string) => controller.answer(answer, state.actionId),
    handleAcknowledgeAnswer: () => controller.acknowledgeAnswer(state.actionId),
    getQuestionTimeRemaining: controller.getQuestionTimeRemaining,
    getDiceTimeRemaining: controller.getDiceTimeRemaining,
    handleUseCleanse: () => controller.apply(true, state.actionId),
    onMovementComplete: (id: number) => controller.send({ type: 'MOTION_DONE', id }),
    onFeedbackDismissed: (id: number) => controller.send({ type: 'ANSWER_FEEDBACK_DISMISSED', id }),
    onSpinComplete: (id: number) => controller.send({ type: 'SPIN_DONE', id }),
    confirmHandover: () => controller.send({ type: 'HANDOVER', id: state.actionId }),
  };
}
