import React, { useEffect } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { cancelAnimation, Easing, useAnimatedStyle, useReducedMotion, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { RescueState } from '../logic/rescue';
import { mobileScene } from '../logic/mobileScene';
import { HIT_MS, METEOR_MS, SHOT_MS, TRAVEL_MS } from '../logic/planets';
import { Background, Planet, Ship } from './SpaceArt';
import { HitSpark, Meteor, ShipSmoke } from './FlightEffects';

function useSegment(active: boolean, elapsed: number, duration: number, paused: boolean, identity: string) {
  const value = useSharedValue(0);
  useEffect(() => {
    cancelAnimation(value); value.set(active ? elapsed / duration : 0);
    if (active && !paused) value.set(withTiming(1, { duration: Math.max(0, duration - elapsed), easing: Easing.linear }));
    return () => cancelAnimation(value);
  }, [active, elapsed, duration, paused, identity, value]);
  return value;
}
/** Both presentations consume the same authoritative timeline and sprite anchors. */
export function JourneyWorld({ state, width, height, scene, compactLabels = false }: {
  state: RescueState; width: number; height: number; scene: ReturnType<typeof mobileScene>; compactLabels?: boolean;
}) {
  const room = state.rooms[state.index], next = state.rooms[state.index + 1];
  const reduced = useReducedMotion(), travelling = state.phase === 'travelling', shot = state.phase === 'firing';
  const freed = ['rescued', 'won', 'travelling'].includes(state.phase);
  const linked = ['compare', 'sum', 'reduce-sum', 'ready', 'firing'].includes(state.phase);
  const identity = `${state.session}:${state.index}`;
  const travel = useSegment(travelling, state.travelMs, TRAVEL_MS, state.paused, identity);
  const flight = useSegment(shot, state.shotMs, SHOT_MS, state.paused, identity);
  const meteor = useSegment(!!state.attack, state.attack?.ms ?? 0, METEOR_MS, state.paused, `${identity}:${state.attack?.id}`);
  const drift = useSharedValue(0);
  useEffect(() => {
    if (!state.paused && !reduced && !travelling && !state.attack && !['won','lost'].includes(state.phase)) drift.set(withRepeat(withTiming(1, { duration: 2200, easing: Easing.inOut(Easing.sin) }), -1, true));
    return () => cancelAnimation(drift);
  }, [state.paused, state.phase, travelling, state.attack, reduced, drift]);
  const shipMotion = useAnimatedStyle(() => {
    const p = travel.value, hit = Math.max(0, (meteor.value - HIT_MS / METEOR_MS) / (1 - HIT_MS / METEOR_MS));
    return { transform: [{ translateX: (reduced ? 0 : Math.sin(p * Math.PI) * width * .13) + (reduced ? 0 : Math.sin(hit * Math.PI * 4) * (1 - hit) * 5) },
      { translateY: reduced ? 0 : drift.value * 3 - Math.sin(p * Math.PI) * Math.min(12, scene.height * .04) }] };
  });
  const oldPlanet = useAnimatedStyle(() => {
    const t = Math.min(1, travel.value / .67), smooth = t * t * (3 - 2 * t);
    return { opacity: reduced && travelling ? 1 - travel.value : 1, transform: [{ translateX: reduced ? 0 : -width * 1.4 * smooth }, { translateY: reduced ? 0 : -Math.sin(t * Math.PI) * scene.height * .42 }] };
  });
  const newPlanet = useAnimatedStyle(() => {
    const t = Math.max(0, Math.min(1, (travel.value - .35) / .65)), smooth = t * t * (3 - 2 * t);
    return { opacity: reduced ? t : 1, transform: [{ translateX: reduced ? 0 : width * 1.1 * (1 - smooth) }] };
  });
  // Retain each segment's camera displacement after arrival: no background snap.
  const index = state.index;
  const parallax = useAnimatedStyle(() => ({ transform: [{ translateX: reduced ? 0 : -width * .025 * (index + travel.value) }] }));
  const streaks = useAnimatedStyle(() => ({ opacity: reduced ? 0 : Math.sin(travel.value * Math.PI) * .7,
    transform: [{ translateX: -width * .35 * travel.value }] }));
  const thruster = useAnimatedStyle(() => ({ opacity: reduced ? .4 : Math.sin(travel.value * Math.PI) * .8, transform: [{ scaleX: 1 + Math.sin(travel.value * Math.PI) * .4 }] }));
  const projectile = useAnimatedStyle(() => {
    const t = reduced ? 1 : Math.min(1, flight.value / .74);
    return { opacity: flight.value >= .08 && flight.value <= .78 ? 1 : 0,
      transform: [{ translateX: (scene.target.x - scene.launch.x) * t }, { translateY: (scene.target.y - scene.launch.y) * t }] };
  });
  const cannonImpact = useAnimatedStyle(() => ({ opacity: flight.value >= .74 ? 1 : 0 }));
  const meteorMotion = useAnimatedStyle(() => {
    const t = Math.min(1, meteor.value * METEOR_MS / HIT_MS);
    return { opacity: meteor.value < HIT_MS / METEOR_MS ? 1 : 0, transform: [
      { translateX: width + 36 + (scene.ship.x + scene.ship.width * .54 - 30 - width - 36) * t },
      { translateY: -70 + (scene.ship.y + scene.ship.height * .48 - 30 + 70) * t },
      { rotate: `${t * -35}deg` },
    ] };
  });
  const hitMotion = useAnimatedStyle(() => ({ opacity: meteor.value >= HIT_MS / METEOR_MS ? (1 - meteor.value) / (1 - HIT_MS / METEOR_MS) : 0 }));
  const planetBox = { position: 'absolute' as const, left: scene.planet.x, top: scene.planet.y, width: scene.planet.width, height: scene.planet.height };
  return <View pointerEvents="none" style={[StyleSheet.absoluteFill, { overflow: 'hidden' }]}>
    <Animated.View testID="rescue-parallax" style={[{ position: 'absolute', left: 0, top: 0, width: width * 1.25, height }, parallax]}><Background /></Animated.View>
    <View testID="rescue-world" style={{ position: 'absolute', top: scene.top, left: 0, width, height: scene.height, overflow: 'hidden' }}>
      {travelling && <Animated.View testID="rescue-star-streaks" style={[StyleSheet.absoluteFill, streaks]}>{[.12,.27,.57,.83].map((y,i) => <View key={y} style={{ position: 'absolute', left: width * (.24 + i * .2), top: scene.height * y, width: 36 + i * 9, height: 2, borderRadius: 2, backgroundColor: '#D9EFF7' }} />)}</Animated.View>}
      <Animated.View testID="rescue-planet" accessibilityLabel={`${room.name} · ${freed ? 'đã tự do' : linked ? 'đã đồng bộ' : 'đang bị khóa'}`} style={[planetBox, oldPlanet]}>
        <Planet theme={room.id} color={room.color} freed={freed} linked={linked} />
        <View style={s.planetLabel}>{!compactLabels && <Text maxFontSizeMultiplier={1.2} style={s.planetName}>{room.name}</Text>}<Text maxFontSizeMultiplier={1.2} style={s.status}>{freed ? 'Đã tự do · Cảm ơn em!' : linked ? 'Đã đồng bộ' : 'Lồng năng lượng đang khóa'}</Text></View>
      </Animated.View>
      {travelling && next && <Animated.View testID="rescue-next-planet" accessibilityLabel={next.name} style={[planetBox, newPlanet]}><Planet theme={next.id} color={next.color} freed={false} linked={false} /><Text maxFontSizeMultiplier={1.2} style={s.planetName}>{next.name}</Text></Animated.View>}
      <Animated.View testID="rescue-ship-group" style={[{ position: 'absolute', left: scene.ship.x, top: scene.ship.y, width: scene.ship.width }, shipMotion]}>
        {travelling && <Animated.View testID="rescue-thruster" style={[{ position: 'absolute', left: 0, top: scene.ship.height * .48, width: scene.ship.width * .18, height: 10, borderRadius: 10, backgroundColor: '#FFD49B' }, thruster]} />}
        <View testID="rescue-ship" style={{ width: scene.ship.width, height: scene.ship.height }}><Ship /></View>
        <View testID="rescue-ship-hp" accessibilityRole="progressbar" accessibilityLabel="Sức khỏe phi thuyền" accessibilityValue={{ min: 0, max: 3, now: state.hull }} style={s.hp}>
          {[1,2,3].map(n => <View key={n} testID={`rescue-hp-${n}`} style={[s.segment, { backgroundColor: n <= state.hull ? state.hull === 1 ? '#EBA77E' : '#91E8C8' : '#334860' }]} />)}<Text maxFontSizeMultiplier={1.2} testID="rescue-hp-value" style={s.hpText}>{state.hull}/3</Text>
        </View>
        <Text maxFontSizeMultiplier={1.2} style={s.shipName}>S.S. MẦM SAO</Text>
        {state.attack && <Animated.View testID="rescue-meteor-impact" style={[{ position: 'absolute', left: scene.ship.width * .3, top: scene.ship.height * .16, width: scene.ship.height * .7, height: scene.ship.height * .7 }, hitMotion]}><HitSpark /></Animated.View>}
        {state.phase === 'lost' && <View style={{ position: 'absolute', width: scene.ship.width * .3, height: scene.ship.height * .6, left: scene.ship.width * .28, top: -scene.ship.height * .12 }}><ShipSmoke /></View>}
      </Animated.View>
      {shot && <Animated.View testID="rescue-projectile" style={[s.projectile, { left: scene.launch.x - 16, top: scene.launch.y - 5 }, projectile]}><View style={s.core} /></Animated.View>}
      {shot && <Animated.View testID="rescue-impact" style={[{ position: 'absolute', left: scene.target.x - 26, top: scene.target.y - 28, width: 52, height: 56 }, cannonImpact]}><HitSpark /></Animated.View>}
      {state.attack && <Animated.View testID="rescue-meteor" style={[{ position: 'absolute', left: 0, top: 0, width: 60, height: 60 }, meteorMotion]}><Meteor /></Animated.View>}
      {state.attack && <Text maxFontSizeMultiplier={1.2} style={s.warning}>{state.attack.hit ? 'Va chạm! Mất 1 HP.' : state.attack.source === 'answer' ? 'Sai rồi · Thiên thạch đang tới!' : 'Hết giờ · Thiên thạch đang tới!'}</Text>}
      {state.mode === 'hard' && state.remaining < 15000 && !state.attack && !freed && <Text maxFontSizeMultiplier={1.2} style={s.warning}>Thiên thạch đang tới!</Text>}
    </View>
  </View>;
}
const s = StyleSheet.create({
  shipName: { color: '#D5E9F3', fontSize: 9, lineHeight: 12, fontWeight: '800', textAlign: 'center', letterSpacing: .6, marginTop: 3 },
  hp: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 8, height: 15 }, segment: { flex: 1, height: 7, borderRadius: 3, borderWidth: 1, borderColor: '#A5C1C9' }, hpText: { color: '#E3F4ED', fontSize: 10, lineHeight: 14, fontWeight: '800', marginLeft: 2 },
  planetLabel: { marginTop: -2 }, planetName: { color: '#FFF1CD', fontWeight: '800', fontSize: 15, lineHeight: 20, textAlign: 'center' }, status: { color: '#D0E2EF', fontSize: 10, lineHeight: 14, textAlign: 'center' }, warning: { position: 'absolute', top: 0, left: 10, color: '#FFD9A5', fontSize: 12, fontWeight: '800' },
  projectile: { position: 'absolute', width: 32, height: 10, borderRadius: 8, backgroundColor: '#79E2D5', borderWidth: 2, borderColor: '#C4FFEE' }, core: { height: 3, margin: 1, borderRadius: 2, backgroundColor: '#FFFFDB' },
});
