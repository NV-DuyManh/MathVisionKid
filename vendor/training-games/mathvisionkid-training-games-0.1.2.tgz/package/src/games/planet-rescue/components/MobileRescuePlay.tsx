import { SpaceScene } from './SpaceScene';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { Fraction as FractionValue } from '../../../shared/math/fraction';
import { useMobileFlow } from '../hooks/useMobileFlow';
import { useRescue } from '../hooks/useRescue';
import { answerOptions, Card, cardAvailable, cardFor, cardReason, MODES, prompt, RescueState } from '../logic/rescue';
import { Button, Fraction } from './RescuePrimitives';
import { INK, SkillIcon } from './SpaceArt';
import { MobileAction } from './MobileAction';

const TEAL = '#247F73';
const INFO: Record<Card, { name: string; color: string; fill: string }> = {
  simplify: { name: 'Thẻ Rút Gọn', color: '#935B27', fill: '#FFF0D6' },
  common: { name: 'Thẻ Quy Đồng', color: TEAL, fill: '#E1F3EA' },
  cannon: { name: 'Pháo Năng Lượng', color: '#6266A3', fill: '#ECECFA' },
};
type Game = ReturnType<typeof useRescue>;
type Flow = ReturnType<typeof useMobileFlow>;

function Feedback({ state, idle = false, message }: { state: RescueState; idle?: boolean; message?: string }) {
  const tone = idle && state.tone === 'info' ? 'info' : state.tone;
  return <View testID="rescue-feedback" accessibilityLiveRegion="polite" style={[s.feedback, { backgroundColor: tone === 'error' ? '#FCEAE3' : tone === 'success' ? '#E6F3E6' : '#F1F0E6' }]}>
    <Text maxFontSizeMultiplier={1.2} style={[s.feedbackIcon, tone === 'error' && { color: '#A04831' }]}>{tone === 'error' ? '!' : tone === 'success' ? '✓' : 'i'}</Text>
    <Text maxFontSizeMultiplier={1.2} style={s.feedbackText}>{message ?? (idle && state.tone === 'info' ? 'Chọn thẻ đang sáng để bắt đầu. Thẻ khóa sẽ mở khi đủ năng lượng.' : state.feedback)}</Text>
  </View>;
}

function Expression({ state, committed }: { state: RescueState; committed: boolean }) {
  const { phase, a, b, sum, denominator } = state;
  const f = (value: FractionValue, unknown = false) => <Fraction value={value} size={21} maxFontSizeMultiplier={1.2} unknown={unknown} color={unknown ? TEAL : INK} />;
  const source = phase === 'numerator-b' ? b : phase === 'reduce-sum' ? sum! : a;
  return <View testID="rescue-expression" style={s.expression}>
    {phase === 'numerator-a' || phase === 'numerator-b' ? <>{f(source)}<Text style={s.operator}>=</Text>{f({ num: 0, den: denominator! }, true)}<Text style={s.mathNote}>× {denominator! / source.den}{'\n'}tử và mẫu</Text></>
      : phase === 'sum' ? <>{f(a)}<Text style={s.operator}>+</Text>{f(b)}<Text style={s.operator}>=</Text>{f({ num: 0, den: denominator! }, true)}</>
      : phase === 'denominator' || phase === 'compare' ? <><Text style={s.sourceName}>A</Text>{f(a)}<Text style={s.operator}>{phase === 'compare' ? '?' : '·'}</Text><Text style={s.sourceName}>B</Text>{f(b)}</>
      : <>{f(source)}<Text style={s.operator}>→</Text><Text style={s.mathNote}>{phase === 'reduce-sum' ? 'Pin tổng' : 'Pin A'}{'\n'}Chia cả tử và mẫu{committed && <Text style={s.committed}>{'\n'}Đã chọn · hoàn tất bước này</Text>}</Text></>}
  </View>;
}

export function MobileMathQuestion({ state, interaction, landscape, intrinsic = false }: { state: RescueState; interaction: Flow; landscape: boolean; intrinsic?: boolean }) {
  const { flow, answer, back } = interaction;
  // Keep the submitted expression/options and selection visible throughout feedback.
  const shown = flow.pending?.before ?? state;
  const task = prompt(shown);
  const options = answerOptions(shown);
  const canBack = flow.canCancel && !flow.pending;
  const introduction = shown.phase.startsWith('reduce') ? 'Chọn ước chung lớn hơn 1 của cả tử và mẫu.' : shown.phase === 'denominator' ? 'Tìm mẫu chung nhỏ nhất của hai nguồn pin.' : shown.phase === 'compare' ? 'Cùng mẫu rồi! Chọn nguồn có tử số lớn hơn.' : shown.phase === 'sum' ? 'Cộng hai tử số, giữ nguyên mẫu chung.' : 'Nhân cả tử và mẫu với cùng một số.';
  return <View testID="rescue-math-panel" style={intrinsic ? { gap: 6 } : s.question}>
    <View style={s.questionHeading}>
      <View style={{ flex: 1, minWidth: 0 }}><Text maxFontSizeMultiplier={1.2} testID="rescue-phase" style={s.eyebrow}>{task.label}</Text><Text maxFontSizeMultiplier={1.2} style={s.questionTitle}>{shown.phase === 'denominator' ? 'Mẫu chung nhỏ nhất là bao nhiêu?' : task.title}</Text></View>
      {canBack && <MobileAction label="Quay lại thẻ" testID="rescue-back-to-cards" onPress={back} style={s.back}><Text maxFontSizeMultiplier={1.3} style={s.backText}>‹ Thẻ</Text></MobileAction>}
    </View>
    <Expression state={shown} committed={!canBack} />
    <View testID="rescue-options" style={s.answers}>{options.map(value => {
      const chosen = flow.pending?.value === value;
      const label = shown.phase === 'compare' ? `Nguồn ${value === 0 ? 'A' : 'B'}` : shown.phase.startsWith('reduce') ? `Chia cho ${value}` : `Chọn ${value}`;
      return <MobileAction key={value} label={label} testID={`rescue-answer-${value}`} selected={chosen} disabled={state.paused || !!flow.pending || !!state.attack}
        onPress={() => answer(value)} style={{ ...s.answer, ...(landscape && options.length === 4 ? { width: '23.7%' } : {}), ...(chosen ? { borderColor: state.tone === 'error' ? '#B46248' : TEAL, backgroundColor: state.tone === 'error' ? '#FCEAE3' : '#E1F3EA' } : {}) }}>
        <View style={s.answerContent}><Text maxFontSizeMultiplier={1.2} style={s.answerText}>{shown.phase === 'compare' ? `Nguồn ${value === 0 ? 'A' : 'B'}` : shown.phase.startsWith('reduce') ? `÷ ${value}` : value}</Text>{shown.phase === 'compare' && <Fraction value={value === 0 ? shown.a : shown.b} size={16} maxFontSizeMultiplier={1.2} />}</View>
      </MobileAction>;
    })}</View>
    <Feedback state={state} message={intrinsic && canBack ? introduction : undefined} />
  </View>;
}

/** The phone dock has exactly one owner: deck, question, shot or next-planet action. */
export function MobileRescuePlay({ game, interaction, onPause, onExit, fire }: {
  game: Game; interaction: Flow; onPause: () => void; onExit: () => void; fire: () => void;
}) {
  const { state, loaded, dispatch, storageError } = game;
  const [size, setSize] = useState({ width: 0, height: 0 });
  const reducedMotion = useReducedMotion();
  const landscape = size.width > size.height && size.height > 0;
  const room = state.rooms[state.index];
  const busy = ['firing', 'travelling', 'rescued', 'won', 'lost'].includes(state.phase);
  const question = !!interaction.flow.card && !busy;
  const questionPhase = interaction.flow.pending?.before.phase ?? state.phase;
  const dockKey = question ? 'question' : state.phase === 'firing' || state.phase === 'rescued' ? state.phase : 'cards';
  const opacity = useSharedValue(1);
  const transition = useAnimatedStyle(() => ({ opacity: opacity.value }));
  useEffect(() => {
    opacity.set(reducedMotion ? 1 : 0);
    if (!reducedMotion) opacity.set(withTiming(1, { duration: 140 }));
  }, [dockKey, reducedMotion, opacity]);
  return <View testID="rescue-mobile-play" style={s.play} onLayout={e => {
    const { width, height } = e.nativeEvent.layout;
    setSize(old => old.width === width && old.height === height ? old : { width, height });
  }}>
    <View testID="rescue-mobile-header" style={s.header}>
      <Button label="Về sảnh" testID="rescue-exit" onPress={onExit} style={s.headerButton}><Text style={s.headerGlyph}>‹</Text></Button>
      <View style={s.headerTitle}><Text accessibilityRole="header" style={s.title}>Giải Cứu Hành Tinh</Text><Text style={s.subtitle}>{MODES[state.mode].title} · {room.name} · {state.index + 1}/{state.rooms.length}</Text></View>
      <Button label="Tạm dừng" testID="rescue-pause" onPress={onPause} style={s.headerButton}><Text style={s.pauseGlyph}>Ⅱ</Text></Button>
    </View>
    <View testID="rescue-status" style={s.status}>
      <Text style={s.mission}>{room.kind === 'reduce-sync' ? 'Rút gọn → Quy Đồng → Pháo' : room.kind === 'sync-sum' ? 'Ghép pin → Rút gọn → Pháo' : room.kind === 'compare' ? 'Quy Đồng → Chọn pin → Pháo' : 'Rút gọn pin → Cứu hành tinh'}</Text>
      {state.mode === 'hard' && <View style={s.shields}><Text testID="rescue-hull" style={s.statusText}>◇ {state.hull}/3</Text><Text testID="rescue-timer" style={[s.statusText, state.remaining < 15000 && { color: '#A04831' }]}>☄ {Math.ceil(state.remaining / 1000)}s</Text></View>}
    </View>
    <View style={[s.body, landscape && s.landscape]}>
      <View style={[s.battlefield, landscape ? { flex: 1 } : { flex: 1, maxHeight: 330 }]}><SpaceScene state={state} compact mobile /></View>
      <View testID="rescue-mobile-dock" style={[s.dock, landscape ? { width: Math.min(400, size.width * .52) } : { height: Math.min(380, Math.max(344, size.height * .47)) }]}>
        <Animated.View key={dockKey} style={[s.dockContent, transition]}>
          {question && questionPhase !== 'ready' ? <MobileMathQuestion state={state} interaction={interaction} landscape={landscape} /> : question && questionPhase === 'ready' ? <View testID="rescue-math-panel" style={s.ready}>
            <SkillIcon kind="cannon" size={48} color={TEAL} /><Text style={s.questionTitle}>Năng lượng đã sẵn sàng!</Text><Text style={s.readyText}>Phá máy tạo lồng, giải phóng hành tinh.</Text>
            <Button label="Khai hỏa" testID="rescue-fire" disabled={state.paused} onPress={fire} style={s.primary}><Text style={s.primaryText}>Khai hỏa cứu hộ →</Text></Button>
            {interaction.flow.canCancel && <Button label="Quay lại thẻ" testID="rescue-back-to-cards" onPress={interaction.back} style={s.back}><Text style={s.backText}>‹ Quay lại thẻ</Text></Button>}
          </View> : busy ? <View testID="rescue-flight-panel" style={s.ready}>
            <SkillIcon kind={state.phase === 'firing' ? 'cannon' : 'star'} size={42} color={TEAL} />
            <Text style={s.questionTitle}>{state.phase === 'lost' ? prompt(state).title : state.phase === 'travelling' ? state.feedback : state.phase === 'firing' ? 'Tia cứu hộ đang tới!' : `${room.name} đã tự do!`}</Text><Feedback state={state} />
            {state.phase === 'rescued' && <Button label={state.index === state.rooms.length - 1 ? 'Hoàn thành hành trình' : 'Hành tinh tiếp theo'} testID="rescue-next" disabled={state.paused} onPress={() => dispatch({ type: 'NEXT' })} style={s.primary}><Text style={s.primaryText}>{state.index === state.rooms.length - 1 ? 'Hoàn thành hành trình ★' : 'Hành tinh tiếp theo →'}</Text></Button>}
          </View> : <View testID="rescue-mobile-cards" style={s.cardPanel}>
            <Text style={s.deckTitle}>Chọn thẻ chiến thuật</Text><Text style={s.deckHint}>{state.mode === 'hard' ? 'Đọc giáp hành tinh rồi chọn thẻ đang sáng.' : 'Chạm thẻ đang sáng để mở bài toán.'}</Text>
            <View style={s.deck}>{(['simplify', 'common', 'cannon'] as Card[]).map(card => {
              const info = INFO[card], enabled = cardAvailable(state, card);
              return <Button key={card} label={info.name} testID={`rescue-card-${card}`} disabled={!loaded || state.paused || !enabled} onPress={() => interaction.open(card)}
                style={{ ...s.card, backgroundColor: enabled ? info.fill : '#F4F4ED', borderColor: enabled ? info.color : '#DEE3D9' }}>
                <View style={s.cardContent}><Text style={[s.cardTag, { color: info.color }]}>{enabled ? state.mode !== 'hard' && cardFor(state.phase) === card ? 'GỢI Ý' : 'SẴN SÀNG' : 'KHÓA'}</Text><SkillIcon kind={card} size={34} color={info.color} /><Text style={s.cardName}>{info.name}</Text><Text style={s.cardHint}>{enabled ? 'Chạm để dùng' : card === 'cannon' ? 'Chờ nạp pin' : 'Chưa cần dùng'}</Text></View>
              </Button>;
            })}</View>
            <Text style={s.lockReason}>{cardReason(state, cardFor(state.phase))}</Text>
            <Feedback state={state} idle />
          </View>}
        </Animated.View>
      </View>
    </View>
    {storageError && <Text style={s.storageWarning}>Chưa lưu được tiến độ · Em vẫn có thể chơi tiếp.</Text>}
  </View>;
}

const s = StyleSheet.create({
  play: { flex: 1, minHeight: 0, paddingHorizontal: 10, paddingTop: 4, paddingBottom: 6 },
  header: { height: 50, flexDirection: 'row', alignItems: 'center', gap: 6 }, headerButton: { width: 48, height: 48, borderRadius: 14, backgroundColor: '#FFFDF7', borderWidth: 1, borderColor: '#DAE2D6' },
  headerGlyph: { fontSize: 31, color: INK, textAlign: 'center' }, pauseGlyph: { fontSize: 22, fontWeight: '800', color: INK, textAlign: 'center' }, headerTitle: { flex: 1, minWidth: 0 }, title: { fontSize: 16, lineHeight: 21, fontWeight: '800', color: INK }, subtitle: { fontSize: 11, lineHeight: 16, color: '#557265' },
  status: { height: 24, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 4 }, mission: { fontSize: 10, color: '#4E6D58', flexShrink: 1 }, shields: { flexDirection: 'row', gap: 6 }, statusText: { color: TEAL, fontSize: 11, fontWeight: '800' },
  body: { flex: 1, minHeight: 0, gap: 6, justifyContent: 'space-between' }, landscape: { flexDirection: 'row' }, battlefield: { minHeight: 100, minWidth: 0 }, dock: { backgroundColor: '#FFFDF7', borderRadius: 18, borderWidth: 1, borderColor: '#DCE4D6', minHeight: 0 }, dockContent: { flex: 1, padding: 10 },
  question: { flex: 1, gap: 6 }, questionHeading: { minHeight: 44, flexDirection: 'row', alignItems: 'center', gap: 6 }, eyebrow: { fontSize: 10, lineHeight: 14, color: TEAL, fontWeight: '800' }, questionTitle: { color: INK, fontSize: 16, lineHeight: 21, fontWeight: '800' }, back: { minWidth: 50, minHeight: 48, borderRadius: 10, backgroundColor: '#EAF0E4' }, backText: { color: TEAL, fontSize: 12, fontWeight: '800', textAlign: 'center', paddingHorizontal: 6 },
  expression: { minHeight: 64, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, backgroundColor: '#F0F4E9', borderRadius: 12, paddingVertical: 3 }, operator: { fontSize: 22, fontWeight: '800', color: '#718B7C' }, mathNote: { color: '#4E6D58', fontSize: 12, lineHeight: 18, textAlign: 'center' }, sourceName: { color: TEAL, fontSize: 12, fontWeight: '800' },
  answers: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, justifyContent: 'space-between' }, answer: { width: '48.7%', minHeight: 52, borderRadius: 12, borderColor: '#DCE4DC', borderWidth: 1, borderBottomWidth: 3, backgroundColor: '#FFFEFA' }, answerContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 4 }, answerText: { color: INK, fontSize: 20, lineHeight: 26, fontWeight: '800' },
  feedback: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, borderRadius: 11, padding: 8, minHeight: 44 }, feedbackIcon: { color: TEAL, fontSize: 16, fontWeight: '800', width: 12 }, feedbackText: { flex: 1, fontSize: 12, lineHeight: 16, color: '#405D47' }, committed: { fontSize: 10, lineHeight: 14, color: '#657D6D' },
  cardPanel: { flex: 1, justifyContent: 'center', gap: 8 }, deckTitle: { color: INK, fontSize: 17, fontWeight: '800' }, deckHint: { fontSize: 12, lineHeight: 17, color: '#607A69' }, deck: { flexDirection: 'row', gap: 6 }, card: { flex: 1, minWidth: 0, borderRadius: 14, borderWidth: 1, borderBottomWidth: 3 }, cardContent: { alignItems: 'center', paddingHorizontal: 3, paddingVertical: 10, gap: 7 }, cardTag: { fontSize: 9, fontWeight: '800' }, cardName: { color: INK, textAlign: 'center', fontSize: 12, lineHeight: 17, fontWeight: '800', minHeight: 34 }, cardHint: { color: '#597261', fontSize: 10, textAlign: 'center' }, lockReason: { color: '#607A69', fontSize: 11, lineHeight: 16 },
  ready: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 }, readyText: { color: '#607A69', fontSize: 12, lineHeight: 18, textAlign: 'center' }, primary: { minHeight: 52, width: '100%', borderRadius: 13, backgroundColor: TEAL, borderBottomWidth: 3, borderColor: '#195D55' }, primaryText: { color: '#FFF9E8', fontWeight: '800', fontSize: 15, textAlign: 'center', padding: 12 }, storageWarning: { fontSize: 10, lineHeight: 14, color: '#9B5435', textAlign: 'center' },
});
