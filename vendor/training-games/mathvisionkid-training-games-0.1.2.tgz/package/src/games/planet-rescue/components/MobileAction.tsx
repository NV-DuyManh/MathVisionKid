import React from 'react';
import { Pressable, StyleSheet, ViewStyle } from 'react-native';

/** One native layout node owns both its surface and intrinsic content size.
 * No flex:1 child inside an auto-height Animated.View (Yoga can collapse it).
 * Desktop continues to use the original Button in RescuePrimitives.
 */
export function MobileAction({ children, onPress, label, testID, disabled = false, selected = false, style }: {
  children: React.ReactNode; onPress: () => void; label: string; testID?: string;
  disabled?: boolean; selected?: boolean; style?: ViewStyle;
}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ disabled, selected }}
    testID={testID} disabled={disabled} onPress={onPress}
    style={({ pressed }) => [styles.surface, style, pressed && { transform: [{ scale: .98 }], borderColor: '#FFE2A3' }]}>
    {children}
  </Pressable>;
}
const styles = StyleSheet.create({ surface: { minHeight: 48, flexShrink: 0, borderRadius: 12, justifyContent: 'center' } });
