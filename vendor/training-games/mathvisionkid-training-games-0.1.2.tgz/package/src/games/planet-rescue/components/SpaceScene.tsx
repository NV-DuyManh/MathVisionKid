import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { RescueState } from '../logic/rescue';
import { JourneyWorld } from './JourneyWorld';

/** Keep the existing framed desktop/landscape shell; share flight/damage rendering. */
export function SpaceScene({ state, compact, mobile = false }: { state: RescueState; compact: boolean; mobile?: boolean }) {
  const [size, setSize] = useState({ width: 700, height: compact ? 270 : 420 });
  const { width, height } = size;
  const shipWidth = Math.min(width * .38, height * .47 * 250 / 170), shipHeight = shipWidth * 170 / 250;
  const planetSize = Math.min(width * .46, height - 68);
  const ship = { x: width * .04, y: Math.min(height * .29, height - shipHeight - 35), width: shipWidth, height: shipHeight };
  const planet = { x: width * .48 + (width * .46 - planetSize) / 2, y: height * .08, width: planetSize, height: planetSize };
  const scene = { top: 0, height, ship, planet,
    launch: { x: ship.x + ship.width * .89, y: ship.y + ship.height * .53 },
    target: { x: planet.x + planetSize * 218 / 280, y: planet.y + planetSize * 49 / 280 },
  };
  return <View testID="rescue-arena" onLayout={e => { const { width, height } = e.nativeEvent.layout; setSize(old => old.width === width && old.height === height ? old : { width, height }); }} style={[s.arena, mobile ? { flex: 1, minHeight: 100, borderRadius: 18 } : { height: compact ? 270 : 420 }]}>
    <JourneyWorld state={state} width={width} height={height} scene={scene} compactLabels={mobile} />
    <View style={s.caption}><View style={s.dot} /><Text style={s.text}>ĐỘI CỨU HỘ SAO NHỎ · HỆ MẶT TRỜI</Text></View>
  </View>;
}
const s = StyleSheet.create({ arena: { borderRadius: 26, overflow: 'hidden', borderWidth: 3, borderColor: '#D8E4E6', backgroundColor: '#203A60' }, caption: { position: 'absolute', top: 12, left: 14, flexDirection: 'row', alignItems: 'center', gap: 7 }, dot: { width: 6, height: 6, backgroundColor: '#94E0C9', borderRadius: 3 }, text: { color: '#B8CBDF', fontSize: 9, letterSpacing: 1, fontWeight: '700' } });
