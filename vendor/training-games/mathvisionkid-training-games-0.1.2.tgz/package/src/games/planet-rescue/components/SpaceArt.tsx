import React, { memo } from 'react';
import Svg, { Circle, ClipPath, Defs, Ellipse, G, LinearGradient, Path, RadialGradient, Rect, Stop } from 'react-native-svg';
import { Card } from '../logic/rescue';
import { PlanetId } from '../logic/planets';

export const INK = '#233653';
export function SkillIcon({ kind, size = 36, color = INK }: { kind: Card | 'shield' | 'star' | 'ship'; size?: number; color?: string }) {
  return <Svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
    {kind === 'simplify' ? <><Circle cx={12} cy={32} r={7} /><Circle cx={32} cy={32} r={7} /><Path d="M17 27 35 7M27 27 10 7M21 22l3 3" /><Circle cx={22} cy={22} r={2} fill={color} /></>
      : kind === 'common' ? <><Path d="M8 19c3-13 25-15 32 0M40 10v10H30M40 29C37 42 15 44 8 29M8 38V28h10" /><Path d="M19 20h10M19 27h10" /></>
      : kind === 'shield' ? <><Path d="m24 4 16 7v13c-2 10-10 16-16 20C18 40 10 34 8 24V11Z" /><Path d="m17 24 5 5 10-12" /></>
      : kind === 'star' ? <Path d="m24 4 6 13 14 2-10 10 2 15-12-7-12 7 2-15L4 19l14-2Z" />
      : <><Path d="M8 30 29 9l13-3-3 13-21 21-2-10Z" fill={kind === 'ship' ? '#FFCD70' : '#85E5D2'} /><Circle cx={30} cy={18} r={4} /><Path d="m9 33-5 11 11-5M11 23l-6 1-1 9M25 37l-1 6-9 1" /></>}
  </Svg>;
}

export const Background = memo(function Background() {
  return <Svg width="100%" height="100%" viewBox="0 0 800 460" preserveAspectRatio="xMidYMid slice">
    <Defs>
      <LinearGradient id="space" x1="0" y1="0" x2="1" y2="1"><Stop offset="0" stopColor="#183960" /><Stop offset="0.6" stopColor="#263967" /><Stop offset="1" stopColor="#47547D" /></LinearGradient>
      <RadialGradient id="cloud"><Stop offset="0" stopColor="#7382B9" stopOpacity=".3" /><Stop offset="1" stopColor="#7382B9" stopOpacity="0" /></RadialGradient>
    </Defs>
    <Rect width={800} height={460} fill="url(#space)" />
    <Ellipse cx={540} cy={240} rx={350} ry={280} fill="url(#cloud)" />
    <Path d="M-70 330Q360-50 870 280M-70 345Q360-35 870 295M90 460Q440 50 850 90" fill="none" stroke="#BCD2ED" opacity={.1} strokeWidth={1.5} />
    {Array.from({ length: 52 }, (_, i) => <G key={i} opacity={.25 + (i % 5) * .13}>
      <Circle cx={(i * 137 + 23) % 790} cy={(i * 83 + 35) % 450} r={i % 7 === 0 ? 2.2 : 1.2} fill="#E3F2FF" />
      {i % 9 === 0 && <Path d={`M${(i * 137 + 23) % 790 - 4} ${(i * 83 + 35) % 450}h8m-4-4v8`} stroke="#E3F2FF" strokeWidth={1} />}
    </G>)}
    <G transform="translate(80 110) rotate(-18)"><Ellipse rx={46} ry={10} stroke="#B0AED1" strokeWidth={5} fill="none" /><Circle r={23} fill="#697BA7" /><Path d="M-18-10q19-6 38 0M-20 3q19-6 41 0" stroke="#91A2C8" strokeWidth={5} /><Path d="M-45 0q45 19 90 0" stroke="#C2C1DF" strokeWidth={5} fill="none" /></G>
    <Circle cx={735} cy={392} r={78} fill="#51668D" opacity={.5} /><Circle cx={711} cy={347} r={12} fill="#7187AA" opacity={.4} />
    <Path d="M-20 439 29 411l33 22 39-13 36 40H-20" fill="#102F50" /><Path d="m25 416 6-5 32 22-4 5" fill="#557298" />
    <G transform="translate(694 84) rotate(20)"><Rect x={-20} y={-7} width={14} height={17} rx={2} fill="#7796BC" stroke="#16334D" strokeWidth={2} /><Rect x={12} y={-7} width={14} height={17} rx={2} fill="#7796BC" stroke="#16334D" strokeWidth={2} /><Rect x={-5} y={-10} width={17} height={23} rx={5} fill="#CEDDEB" /><Path d="M3-10v-8m-6 0h12" stroke="#CEDDEB" strokeWidth={3} /></G>
  </Svg>;
});

export const Planet = memo(function Planet({ color, freed, linked, theme = 'earth' }: { color: string; freed: boolean; linked: boolean; theme?: PlanetId }) {
  const gradient = `planet-${theme}`, clip = `surface-${theme}`;
  return <Svg width="100%" height="100%" viewBox="0 0 280 280">
    <Defs><RadialGradient id={gradient}><Stop offset="0" stopColor="#F1E9CD" /><Stop offset=".5" stopColor={color} /><Stop offset="1" stopColor={color} /></RadialGradient><ClipPath id={clip}><Circle cx={140} cy={135} r={87} /></ClipPath></Defs>
    <Ellipse cx={142} cy={240} rx={76} ry={12} fill="#102A47" opacity={.3} />
    {theme === 'saturn' && <G transform="translate(140 139) rotate(-20)"><Ellipse rx={129} ry={35} fill="none" stroke="#D4B982" strokeWidth={16} /></G>}
    <Circle cx={140} cy={135} r={104} fill={freed ? '#D8FFBF' : '#A5C5FA'} opacity={.08} />
    <Circle cx={140} cy={135} r={88} fill={`url(#${gradient})`} stroke="#163F53" strokeWidth={4} />
    <G clipPath={`url(#${clip})`}>
      {theme === 'earth' ? <Path d="M79 76q19-20 44-18l5 15-13 15 3 14-17 5-17-9-16 10M184 66l-17 29 15 15 25-5 12 22M65 155l29-12 28 21-7 21-22 12M179 188l-13-12 8-20 21-5 15 18" fill="#429E70" opacity={.88} />
        : theme === 'mercury' || theme === 'mars' ? <>
          <Path d="m51 145 30-26 22 8 11 23-21 25-29-2ZM168 48l29 13 19 33-28-7-22-21" fill={theme === 'mars' ? '#A94F42' : '#7D858C'} opacity={.4} />
          {[[85,91,16],[184,90,21],[75,171,9],[181,183,18],[139,61,8]].map(([x,y,r]) => <G key={x}><Circle cx={x} cy={y} r={r} fill={theme === 'mars' ? '#C26A56' : '#969493'} stroke={theme === 'mars' ? '#AB594B' : '#858184'} strokeWidth={2} /><Path d={`M${x-r*.6} ${y+r*.25}q${r*.6} ${r*.6} ${r*1.2} 0`} stroke={theme === 'mars' ? '#EBA488' : '#D3CFC6'} fill="none" strokeWidth={2} /></G>)}
        </> : <>
          {[70,94,151,177,203].map((y,i) => <Path key={y} d={`M35 ${y}Q130 ${y+17} 246 ${y-4}`} fill="none" stroke={theme === 'venus' ? ['#F8D687','#C88C53'][i%2] : theme === 'jupiter' ? ['#A8745F','#F7DEC2'][i%2] : theme === 'saturn' ? ['#C3A56E','#F6E3B3'][i%2] : theme === 'neptune' ? ['#3866AC','#A1C4F2'][i%2] : ['#C5F1E6','#67B7C4'][i%2]} strokeWidth={theme === 'venus' ? 17 : 12} opacity={.65} />)}
          {theme === 'jupiter' && <><G transform="translate(188 163) rotate(-10)"><Ellipse rx={23} ry={12} fill="#BD705E" stroke="#E6A077" strokeWidth={4} /></G><Path d="M174 163q12-10 27-1" stroke="#8A5149" strokeWidth={2} fill="none" /></>}
          {theme === 'neptune' && <Ellipse cx={90} cy={165} rx={17} ry={8} fill="#355B9D" />}
          {theme === 'uranus' && <Path d="M97 39q-37 107 25 203M117 32q-36 111 25 208" stroke="#DEF6EB" strokeWidth={5} opacity={.45} fill="none" />}
        </>}
    </G>
    {theme === 'saturn' && <Path d="M19 181q99 23 240-84" fill="none" stroke="#F0D7A4" strokeWidth={10} strokeLinecap="round" />}
    <Path d="M77 96q11-22 32-26" stroke="#FFFBE2" opacity={.75} strokeWidth={7} strokeLinecap="round" />
    <G transform="translate(104 117)"><Ellipse cx={0} cy={8} rx={5} ry={7} fill={INK} /><Ellipse cx={65} cy={8} rx={5} ry={7} fill={INK} /><Circle cx={-9} cy={22} r={7} fill="#EF9D93" opacity={.7} /><Circle cx={74} cy={22} r={7} fill="#EF9D93" opacity={.7} /><Path d={freed ? 'M22 22q11 16 23 0' : 'M24 30q10-9 20 0'} stroke={INK} strokeWidth={3} strokeLinecap="round" fill="none" /></G>
    <G transform="translate(109 195)"><Rect x={-14} y={-9} width={28} height={23} rx={5} fill="#FFF6D8" stroke={INK} strokeWidth={2} /><Path d="m-18-9 18-15 18 15" fill="#F7A56F" stroke={INK} strokeWidth={2} /><Rect x={-4} y={1} width={8} height={12} rx={2} fill="#70BBCB" /></G>
    <G transform="translate(166 205)"><Rect x={-11} y={-18} width={22} height={25} rx={4} fill="#E7E8FF" stroke={INK} strokeWidth={2} /><Path d="m-15-18 15-15 15 15" fill="#A397D9" stroke={INK} strokeWidth={2} /><Circle cy={-8} r={4} fill="#FFDB86" /></G>
    {!freed && <G stroke={linked ? '#8BE9CE' : '#FFCF8A'} fill="none" strokeWidth={2.4} opacity={.85}>
      <Ellipse cx={140} cy={135} rx={104} ry={104} strokeDasharray={linked ? '9 11' : undefined} />
      {!linked && <><Ellipse cx={140} cy={135} rx={51} ry={104} /><Ellipse cx={140} cy={135} rx={104} ry={38} /><Path d="M36 135h208M140 31v208" opacity={.6} /></>}
    </G>}
    {!freed && <G transform="translate(218 49)"><Path d="m-21 0 11-19h24L26 0 14 20h-24Z" fill="#40567E" stroke="#152C49" strokeWidth={3} /><Circle r={9} fill={linked ? '#88EACF' : '#FFD28C'} /><Path d="M-4-2v6h8v-6m-7 0v-3a3 3 0 0 1 6 0v3" stroke="#294362" strokeWidth={2} fill="none" /></G>}
    {freed && <G fill="#FFE8A6" stroke="#FFF1C4" strokeWidth={2}><Path d="m51 46 3-9 3 9 9 3-9 3-3 9-3-9-9-3ZM235 172l3-9 3 9 9 3-9 3-3 9-3-9-9-3Z" /><Path d="m63 232 6-6m156-9 5 7M206 31l5-6" /></G>}
  </Svg>;
});

export const Ship = memo(function Ship() {
  return <Svg width="100%" height="100%" viewBox="0 0 250 170">
    <Defs><LinearGradient id="glass" x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor="#C5F3F3" /><Stop offset="1" stopColor="#50B8CF" /></LinearGradient></Defs>
    <Ellipse cx={135} cy={150} rx={77} ry={8} fill="#0E2845" opacity={.3} />
    <Path d="m56 73-38 17 38 17-7-17Z" fill="#F4A460" /><Path d="m56 80-23 10 23 10" fill="#FFEEAE" />
    <Path d="m77 56-10-35 18-5 49 44M90 117l-8 28 21 2 40-29" fill="#EB9875" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    <Path d="M54 69q51-31 108-10l48 31-48 31q-57 21-108-10Z" fill="#F4EBD9" stroke={INK} strokeWidth={4} />
    <Path d="M60 103q65 30 129-7l21-6-48 31q-57 21-108-10Z" fill="#B9CAD7" />
    <Path d="M111 61q-5-43 30-42 33 3 31 46" fill="url(#glass)" stroke={INK} strokeWidth={4} />
    <Path d="M123 44q-3-17 11-20" fill="none" stroke="#FFF7DD" strokeWidth={5} strokeLinecap="round" />
    <G transform="translate(147 43)"><Rect x={-12} y={-8} width={25} height={24} rx={9} fill="#FFF8DF" stroke={INK} strokeWidth={2.5} /><Rect x={-8} y={-1} width={17} height={10} rx={4} fill="#3C617D" /><Circle cx={-3} cy={3} r={2} fill="#98EFDA" /><Circle cx={5} cy={3} r={2} fill="#98EFDA" /><Path d="M1-8v-6" stroke={INK} strokeWidth={2} /><Circle cx={1} cy={-16} r={3} fill="#FFBD79" /></G>
    <Path d="M77 68v44M91 66v48" stroke="#EB9875" strokeWidth={7} />
    <Path d="m109 102 27-25 30 9-39 28Z" fill="#F5AE7F" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
    <Circle cx={182} cy={90} r={5} fill="#7ADDCB" stroke={INK} strokeWidth={2} /><Rect x={46} y={67} width={14} height={46} rx={5} fill="#5F829B" stroke={INK} strokeWidth={3} />
    <Path d="m203 85 20-2v14l-20-2" fill="#A4DCD9" stroke={INK} strokeWidth={3} /><Path d="M62 59h26M112 128l18-6" stroke="#F5EAD7" strokeWidth={2} strokeLinecap="round" />
  </Svg>;
});

