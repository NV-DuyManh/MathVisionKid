import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { Fraction as FractionType } from '../../../shared/math/fraction';
import { INK } from './SpaceArt';

export function Button({ children, onPress, label, testID, disabled = false, style, selected = false }: {
  children: React.ReactNode; onPress: () => void; label: string; testID?: string; disabled?: boolean; style?: ViewStyle; selected?: boolean;
}) {
  const scale = useSharedValue(1);
  const motion = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const [hovered, setHovered] = useState(false);
  return <Animated.View style={[style, motion]}>
    <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ disabled, selected }} testID={testID}
      disabled={disabled} onPress={onPress} onHoverIn={() => setHovered(true)} onHoverOut={() => setHovered(false)}
      onPressIn={() => scale.set(withTiming(.97, { duration: 90 }))} onPressOut={() => scale.set(withTiming(1, { duration: 130 }))}
      style={[styles.buttonContent, hovered && !disabled && { backgroundColor: '#FFFFFF22' }, disabled && { opacity: .5 }]}>
      {children}
    </Pressable>
  </Animated.View>;
}
export function Fraction({ value, size = 26, color = INK, unknown = false, maxFontSizeMultiplier }: { value: FractionType; size?: number; color?: string; unknown?: boolean; maxFontSizeMultiplier?: number }) {
  return <View accessible accessibilityLabel={`${unknown ? 'chưa biết' : value.num} phần ${value.den}`} style={styles.fraction}>
    <Text maxFontSizeMultiplier={maxFontSizeMultiplier} style={{ color, fontSize: size, lineHeight: size * 1.22, fontWeight: '800', textAlign: 'center' }}>{unknown ? '?' : value.num}</Text>
    <View style={{ height: 2, backgroundColor: color, minWidth: size * .95, width: '100%', marginVertical: 3, borderRadius: 2 }} />
    <Text maxFontSizeMultiplier={maxFontSizeMultiplier} style={{ color, fontSize: size, lineHeight: size * 1.22, fontWeight: '800', textAlign: 'center' }}>{value.den}</Text>
  </View>;
}
const styles = StyleSheet.create({
  buttonContent: { flex: 1, borderRadius: 12, justifyContent: 'center' },
  fraction: { alignItems: 'center', paddingHorizontal: 3, minWidth: 24 },
});
