import React, { memo } from 'react';
import Svg, { Circle, Ellipse, G, Path } from 'react-native-svg';

export const Meteor = memo(function Meteor() {
  return <Svg width="100%" height="100%" viewBox="0 0 100 100">
    <Path d="m35 65 52-61-9 36 20-12-33 48" fill="#EAA56F" opacity={.7} />
    <Path d="m43 63 37-40-15 39 17-10-27 27" fill="#FFE0A2" />
    <Path d="m19 38 21-8 23 10 10 23-15 22-28 4-19-17-3-19Z" fill="#B88670" stroke="#3A4058" strokeWidth={3} strokeLinejoin="round" />
    <Path d="m12 64 19 15 27-2 13-13-13 21-28 4-19-17Z" fill="#8B665F" />
    <Ellipse cx={31} cy={52} rx={10} ry={8} fill="#8F6A61" stroke="#D2A083" strokeWidth={2} />
    <Circle cx={53} cy={67} r={8} fill="#8D645B" /><Circle cx={31} cy={74} r={4} fill="#D1A086" />
    <Path d="m23 40 15-4 11 4M59 46l6 10" fill="none" stroke="#F3C7A0" strokeWidth={3} strokeLinecap="round" />
  </Svg>;
});
export const HitSpark = memo(function HitSpark() {
  return <Svg width="100%" height="100%" viewBox="0 0 100 100"><G fill="#FFDF9E" stroke="#FFF0CA" strokeWidth={2}><Path d="m50 17 8 22 24-8-13 22 13 17-24-5-10 21-7-23-24 4 16-18-10-20 23 9Z" /><Path d="m12 14 9 8m61-7-7 9M9 80l11-6m63 7-9-8" strokeWidth={4} strokeLinecap="round" /></G></Svg>;
});
export const ShipSmoke = memo(function ShipSmoke() {
  return <Svg width="100%" height="100%" viewBox="0 0 100 100"><Circle cx={42} cy={62} r={22} fill="#B7BED2" opacity={.65} /><Circle cx={58} cy={42} r={18} fill="#D0D6DE" opacity={.55} /><Circle cx={45} cy={20} r={12} fill="#D9DDE4" opacity={.4} /></Svg>;
});
