import React from 'react';
import { StyleSheet, View } from 'react-native';
import { RescueState } from '../logic/rescue';
import { mobileScene } from '../logic/mobileScene';
import { JourneyWorld } from './JourneyWorld';

export function FullscreenSpaceScene({ state, width, height, hud, dock, compactLabels = false }: { state: RescueState; width: number; height: number; hud: number; dock: number; compactLabels?: boolean }) {
  const scene = mobileScene(width, height, hud, dock, compactLabels ? 18 : 36);
  return <View testID="rescue-arena" pointerEvents="none" style={StyleSheet.absoluteFill}><JourneyWorld state={state} width={width} height={height} scene={scene} compactLabels={compactLabels} /></View>;
}
