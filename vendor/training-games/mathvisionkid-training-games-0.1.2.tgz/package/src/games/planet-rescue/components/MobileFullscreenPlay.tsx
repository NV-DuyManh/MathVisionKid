import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { useRescue } from '../hooks/useRescue';
import { useMobileFlow } from '../hooks/useMobileFlow';
import { Card, cardAvailable, cardFor, MODES, RescueState } from '../logic/rescue';
import { SkillIcon } from './SpaceArt';
import { FullscreenSpaceScene } from './FullscreenSpaceScene';
import { MobileAction } from './MobileAction';
import { MobileMathQuestion } from './MobileRescuePlay';

const INFO: Record<Card, { name: string; color: string; fill: string }> = {
  simplify: { name: 'Thẻ Rút Gọn', color: '#F9D098', fill: '#5A442F' },
  common: { name: 'Thẻ Quy Đồng', color: '#95E4D2', fill: '#23534F' },
  cannon: { name: 'Pháo Năng Lượng', color: '#CEC9FF', fill: '#44496B' },
};
export function skillStatus(state: RescueState, card: Card) {
  if (state.phase === 'firing') return { tag: card === 'cannon' ? 'ĐANG BẮN' : 'ĐỢI HIỆU ỨNG', hint: 'Đang cứu hộ' };
  if (state.phase === 'rescued' || state.phase === 'won') return { tag: 'HOÀN TẤT', hint: 'Đã giải cứu' };
  if (cardAvailable(state, card)) return { tag: state.mode !== 'hard' && card === cardFor(state.phase) ? 'GỢI Ý' : 'SẴN SÀNG', hint: 'Chạm để dùng' };
  if (card === 'cannon') return { tag: 'KHÓA', hint: 'Cần pin đã nạp' };
  if (card === 'common') return state.rooms[state.index].kind === 'reduce' ? { tag: 'KHÔNG CẦN', hint: 'Chỉ cần Rút Gọn' } : state.phase === 'reduce-first' ? { tag: 'KHÓA', hint: 'Rút Gọn pin A trước' } : { tag: 'ĐÃ XỬ LÝ', hint: 'Hai pin đã đồng bộ' };
  return state.rooms[state.index].kind === 'sync-sum' && !state.sum ? { tag: 'KHÓA', hint: 'Ghép pin tổng trước' } : { tag: 'ĐÃ XỬ LÝ', hint: 'Không cần rút gọn' };
}

export function MobileFullscreenPlay({ game, interaction, onPause, onExit, fire }: {
  game: ReturnType<typeof useRescue>; interaction: ReturnType<typeof useMobileFlow>; onPause: () => void; onExit: () => void; fire: () => void;
}) {
  const { state, loaded, dispatch, storageError } = game;
  const [size, setSize] = useState({ width: 320, height: 568 });
  const [dock, setDock] = useState(170), [hud, setHud] = useState(64);
  const busy = ['firing', 'travelling', 'rescued', 'won', 'lost'].includes(state.phase);
  const question = !!interaction.flow.card && !busy;
  const shownPhase = interaction.flow.pending?.before.phase ?? state.phase;
  const dockKey = question ? 'question' : busy ? state.phase : 'cards';
  const opacity = useSharedValue(1), reduced = useReducedMotion();
  const transition = useAnimatedStyle(() => ({ opacity: opacity.value }));
  useEffect(() => { opacity.set(reduced ? 1 : 0); if (!reduced) opacity.set(withTiming(1, { duration: 140 })); }, [dockKey, reduced, opacity]);
  return <View testID="rescue-mobile-play" style={s.root} onLayout={e => { const { width, height } = e.nativeEvent.layout; setSize(old => old.width === width && old.height === height ? old : { width, height }); }}>
    <FullscreenSpaceScene state={state} width={size.width} height={size.height} hud={hud} dock={dock} compactLabels={question} />
    <View testID="rescue-mobile-header" style={s.hud} onLayout={e => setHud(e.nativeEvent.layout.height)}>
      <View style={s.headerRow}><MobileAction label="Về sảnh" testID="rescue-exit" onPress={onExit} style={s.hudButton}><Text maxFontSizeMultiplier={1.2} style={s.back}>‹</Text></MobileAction>
        <View style={s.heading}><Text maxFontSizeMultiplier={1.2} testID="rescue-room" style={s.planetTitle}>{state.rooms[state.index].name}</Text><Text maxFontSizeMultiplier={1.2} style={s.subtitle}>{MODES[state.mode].title} · Hành tinh {state.index + 1}/{state.rooms.length}</Text></View>
        <MobileAction label="Tạm dừng" testID="rescue-pause" onPress={onPause} style={s.hudButton}><Text maxFontSizeMultiplier={1.2} style={s.pause}>Ⅱ</Text></MobileAction></View>
      <View testID="rescue-status" style={s.status}><Text maxFontSizeMultiplier={1.2} style={s.mission}>{state.rooms[state.index].kind === 'sync-sum' ? 'LỒNG ĐÔI · GHÉP HAI NGUỒN PIN' : state.rooms[state.index].kind === 'reduce-sync' ? 'GIÁP LỌC · RÚT GỌN RỒI QUY ĐỒNG' : 'BIỆT ĐỘI SAO NHỎ · CỨU HỘ'}</Text>{state.mode === 'hard' && <View style={s.vitals}><Text maxFontSizeMultiplier={1.2} testID="rescue-hull" style={s.vital}>◇ {state.hull}/3</Text><Text maxFontSizeMultiplier={1.2} testID="rescue-timer" style={s.vital}>☄ {Math.ceil(state.remaining / 1000)}s</Text></View>}</View>
    </View>
    <View testID="rescue-mobile-dock" onLayout={e => setDock(e.nativeEvent.layout.height)} style={[s.dock, question && s.mathDock]}>
      <Animated.View key={dockKey} style={transition}>
        {question && shownPhase !== 'ready' ? <MobileMathQuestion state={state} interaction={interaction} landscape={false} intrinsic /> : question ? <View testID="rescue-math-panel" style={s.actionPanel}>
          <View style={s.actionTitle}><SkillIcon kind="cannon" size={28} color="#247F73" /><Text maxFontSizeMultiplier={1.3} style={s.darkTitle}>Năng lượng đã sẵn sàng!</Text></View>
          <MobileAction label="Khai hỏa" testID="rescue-fire" disabled={state.paused} onPress={fire} style={s.primary}><Text maxFontSizeMultiplier={1.3} style={s.primaryText}>Khai hỏa cứu hộ →</Text></MobileAction>
          {interaction.flow.canCancel && <MobileAction label="Quay lại thẻ" testID="rescue-back-to-cards" onPress={interaction.back}><Text maxFontSizeMultiplier={1.3} style={s.link}>‹ Quay lại thẻ</Text></MobileAction>}
        </View> : busy ? <View testID="rescue-flight-panel" style={s.actionPanel}>
          <View style={{ alignSelf: 'center' }}><SkillIcon kind={state.phase === 'firing' ? 'cannon' : 'star'} size={30} color="#A9E9D2" /></View>
          <Text maxFontSizeMultiplier={1.3} style={s.lightTitle}>{state.phase === 'lost' ? 'Cùng Nova sửa tàu nhé!' : state.phase === 'travelling' ? `Tới ${state.rooms[state.index + 1]?.name}…` : state.phase === 'firing' ? 'Tia cứu hộ đang tới!' : `${state.rooms[state.index].name} đã tự do!`}</Text>
          {state.phase === 'travelling' && <Text maxFontSizeMultiplier={1.2} style={s.flightHint}>Nova đang dẫn đường · Đợi tàu tới nơi nhé!</Text>}
          {state.phase === 'firing' && <Text maxFontSizeMultiplier={1.2} style={s.flightHint}>Đợi tia cứu hộ phá máy tạo lồng.</Text>}
          {state.phase === 'rescued' && <MobileAction label={state.index === state.rooms.length - 1 ? 'Hoàn thành hành trình' : 'Hành tinh tiếp theo'} testID="rescue-next" disabled={state.paused} onPress={() => dispatch({ type: 'NEXT' })} style={s.primary}><Text maxFontSizeMultiplier={1.3} style={s.primaryText}>{state.index === state.rooms.length - 1 ? 'Hoàn thành hành trình ★' : 'Hành tinh tiếp theo →'}</Text></MobileAction>}
        </View> : <View testID="rescue-mobile-cards" style={s.cardPanel}>
          <Text maxFontSizeMultiplier={1.2} style={s.deckLabel}>CHỌN THẺ CHIẾN THUẬT</Text>
          <View style={s.deck}>{(['simplify', 'common', 'cannon'] as Card[]).map(card => {
            const info = INFO[card], enabled = cardAvailable(state, card), status = skillStatus(state, card);
            return <MobileAction key={card} label={`${info.name}. ${status.tag}. ${status.hint}`} testID={`rescue-card-${card}`} disabled={!loaded || state.paused || !enabled} selected={false} onPress={() => interaction.open(card)}
              style={{ ...s.card, borderColor: enabled ? info.color : '#688095', backgroundColor: enabled ? info.fill : '#243C54' }}>
              <View testID={`rescue-card-content-${card}`} style={s.cardContent}><Text maxFontSizeMultiplier={1.2} style={[s.cardState, { color: enabled ? info.color : '#BBCBD6' }]}>{status.tag}</Text><View testID={`rescue-card-icon-${card}`} style={s.icon}><SkillIcon kind={card} size={30} color={enabled ? info.color : '#B3C4D4'} /></View><Text maxFontSizeMultiplier={1.3} testID={`rescue-card-name-${card}`} style={s.cardName}>{info.name}</Text><Text maxFontSizeMultiplier={1.2} style={s.cardHint}>{status.hint}</Text></View>
            </MobileAction>;
          })}</View>
        </View>}
      </Animated.View>
      {storageError && <Text maxFontSizeMultiplier={1.2} style={s.storage}>Chưa lưu được tiến độ · Em vẫn có thể chơi tiếp.</Text>}
    </View>
  </View>;
}
const s = StyleSheet.create({
  root: { flex: 1, minHeight: 0, backgroundColor: '#183960' }, hud: { position: 'absolute', top: 6, left: 10, right: 10, borderRadius: 16, backgroundColor: '#102D48E8', padding: 6, gap: 4, borderWidth: 1, borderColor: '#698599' }, headerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 }, hudButton: { width: 48, height: 48, backgroundColor: '#264960', borderWidth: 1, borderColor: '#6B8796' }, back: { color: '#FFF1D1', fontSize: 30, textAlign: 'center' }, pause: { color: '#FFF1D1', fontSize: 22, fontWeight: '800', textAlign: 'center' }, heading: { flex: 1, minWidth: 0 }, planetTitle: { fontSize: 17, lineHeight: 22, fontWeight: '800', color: '#FFF1CF' }, subtitle: { color: '#CDDFE5', fontSize: 11, lineHeight: 16 }, status: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 4 }, mission: { color: '#B7D3DF', fontSize: 8, lineHeight: 12, flexShrink: 1, letterSpacing: .2 }, vitals: { flexDirection: 'row', gap: 7 }, vital: { color: '#FFD6A0', fontSize: 11, lineHeight: 14, fontWeight: '800' },
  dock: { position: 'absolute', bottom: 6, left: 10, right: 10, padding: 9, borderRadius: 18, borderWidth: 1, borderColor: '#7895A5', backgroundColor: '#102B46EF' }, mathDock: { backgroundColor: '#FFFDF4', borderColor: '#AFC8BF' }, cardPanel: { gap: 6 }, deckLabel: { fontSize: 10, lineHeight: 14, letterSpacing: .8, color: '#D6E7EC', fontWeight: '800' }, deck: { flexDirection: 'row', alignItems: 'stretch', gap: 6 }, card: { flex: 1, minWidth: 0, borderRadius: 13, borderWidth: 1, borderBottomWidth: 3 }, cardContent: { paddingHorizontal: 3, paddingVertical: 7, alignItems: 'center', gap: 4 }, cardState: { fontSize: 8, lineHeight: 11, fontWeight: '800', textAlign: 'center' }, icon: { height: 32, width: 36, alignItems: 'center', justifyContent: 'center' }, cardName: { fontSize: 12, lineHeight: 16, minHeight: 32, color: '#FFF4D8', fontWeight: '800', textAlign: 'center', alignSelf: 'stretch' }, cardHint: { fontSize: 10, lineHeight: 13, minHeight: 26, color: '#CFDFE8', textAlign: 'center', alignSelf: 'stretch' },
  actionPanel: { gap: 8, minHeight: 144, justifyContent: 'center' }, actionTitle: { flexDirection: 'row', alignItems: 'center', gap: 8 }, darkTitle: { color: '#233653', fontSize: 16, lineHeight: 22, fontWeight: '800', flexShrink: 1 }, lightTitle: { color: '#FFF1CD', fontSize: 17, lineHeight: 23, fontWeight: '800', textAlign: 'center' }, flightHint: { color: '#C7DFE8', fontSize: 12, lineHeight: 17, textAlign: 'center' }, primary: { backgroundColor: '#287E70', minHeight: 52, borderWidth: 1, borderColor: '#8DC6AA' }, primaryText: { color: '#FFF5D8', fontSize: 15, lineHeight: 21, fontWeight: '800', padding: 11, textAlign: 'center' }, link: { color: '#247F73', fontSize: 12, fontWeight: '800', textAlign: 'center', padding: 8 }, storage: { color: '#FFE0AF', fontSize: 10, lineHeight: 14, marginTop: 5 },
});
