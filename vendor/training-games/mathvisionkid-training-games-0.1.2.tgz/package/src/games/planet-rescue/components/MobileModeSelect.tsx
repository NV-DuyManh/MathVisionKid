import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Mode, MODES } from '../logic/rescue';
import { MobileAction } from './MobileAction';
import { Background, Planet, Ship, SkillIcon } from './SpaceArt';

const DETAILS: Record<Mode, { difficulty: string; description: string; color: string; icon: 'simplify' | 'common' | 'cannon' }> = {
  easy: { difficulty: 'Dễ', description: 'Phân số & Thẻ Rút Gọn', color: '#72DCC1', icon: 'simplify' },
  medium: { difficulty: 'Vừa sức', description: 'Quy Đồng rồi so sánh pin', color: '#AEBEFF', icon: 'common' },
  hard: { difficulty: 'Khó hơn', description: 'Combo thẻ & thiên thạch', color: '#FFCC85', icon: 'cannon' },
};
export function MobileModeSelect({ selected, onSelect, onStart, onExit, loaded }: {
  selected: Mode; onSelect: (mode: Mode) => void; onStart: () => void; onExit: () => void;
  loaded: boolean;
}) {
  const [height, setHeight] = useState(0);
  const [listHeight, setListHeight] = useState(0);
  const { fontScale } = useWindowDimensions();
  const tight = height > 0 && height < 640;
  return <View testID="rescue-mode-select" style={[s.page, tight && { gap: 6 }]} onLayout={e => setHeight(e.nativeEvent.layout.height)}>
    <View style={s.header}><MobileAction label="Về sảnh" testID="rescue-picker-exit" onPress={onExit} style={s.back}><Text maxFontSizeMultiplier={1.3} style={s.backText}>‹</Text></MobileAction><View style={{ flex: 1 }}><Text maxFontSizeMultiplier={1.3} style={s.brand}>BIỆT ĐỘI SAO NHỎ</Text><Text maxFontSizeMultiplier={1.3} style={s.title}>Giải Cứu Hành Tinh</Text></View></View>
    <View testID="rescue-mode-banner" style={[s.banner, { height: tight ? 80 : 118 }]}>
      <View style={StyleSheet.absoluteFill}><Background /></View><View style={s.bannerShip}><Ship /></View><View style={s.bannerPlanet}><Planet color="#64D7BC" freed={false} linked={false} /></View>
      {!tight && <View style={s.bannerCopy}><Text maxFontSizeMultiplier={1.3} style={s.bannerTitle}>Một phép tính nhỏ,{'\n'}một hành tinh được cứu!</Text></View>}
    </View>
    <Text maxFontSizeMultiplier={1.3} style={s.label}>CHỌN NHIỆM VỤ CỦA EM</Text>
    <ScrollView testID="rescue-mode-list" onLayout={e => setListHeight(e.nativeEvent.layout.height)} style={{ flex: 1, minHeight: 0 }} contentContainerStyle={{ gap: tight ? 6 : 10, paddingBottom: 2 }} showsVerticalScrollIndicator={fontScale > 1.05}>{(['easy', 'medium', 'hard'] as Mode[]).map(mode => {
      const info = DETAILS[mode], active = mode === selected;
      return <MobileAction key={mode} label={MODES[mode].title} testID={`rescue-mode-${mode}`} selected={active} disabled={!loaded} onPress={() => onSelect(mode)}
        style={{ ...s.mode, minHeight: Math.max(72, (listHeight - (tight ? 12 : 20) - 2) / 3), paddingVertical: tight ? 6 : 14, borderColor: active ? info.color : '#344E68', backgroundColor: active ? '#244A59' : '#182F48' }}>
        <View style={[s.modeIcon, { backgroundColor: active ? '#376456' : '#273D55' }]}><SkillIcon kind={info.icon} size={tight ? 27 : 34} color={info.color} /></View>
        <View style={[s.modeCopy, tight && { gap: 2 }]}><View style={s.modeHeading}><Text maxFontSizeMultiplier={1.3} style={[s.modeTitle, tight && { fontSize: 16, lineHeight: 20 }]}>{MODES[mode].title}</Text><Text maxFontSizeMultiplier={1.3} style={[s.difficulty, { color: info.color }]}>{info.difficulty}</Text></View><Text maxFontSizeMultiplier={1.3} style={[s.description, tight && { fontSize: 11, lineHeight: 15 }]}>{info.description}</Text><Text maxFontSizeMultiplier={1.3} style={[s.count, tight && { fontSize: 9, lineHeight: 12 }]}>{MODES[mode].count} hành tinh · {MODES[mode].subtitle}</Text></View>
        <View testID={`rescue-mode-indicator-${mode}`} style={[s.indicator, active && { backgroundColor: info.color, borderColor: info.color }]} />
      </MobileAction>;
    })}</ScrollView>
    <MobileAction label="Bắt đầu" testID="rescue-start" disabled={!loaded} onPress={onStart} style={{ ...s.start, opacity: loaded ? 1 : .7 }}><Text maxFontSizeMultiplier={1.3} style={s.startText}>▶  BẮT ĐẦU</Text></MobileAction>
    {!tight && <Text maxFontSizeMultiplier={1.3} style={s.footer}>Chọn chế độ rồi bắt đầu. Đồng hồ đang nghỉ.</Text>}
  </View>;
}
const s = StyleSheet.create({
  page: { flex: 1, paddingHorizontal: 12, paddingVertical: 8, gap: 10, backgroundColor: '#10283F' }, header: { flexDirection: 'row', alignItems: 'center', gap: 10 }, back: { width: 48, height: 48, backgroundColor: '#203E56', borderWidth: 1, borderColor: '#466175' }, backText: { color: '#FFF5D8', fontSize: 30, textAlign: 'center' }, brand: { fontSize: 9, letterSpacing: 1, color: '#A7C4D3' }, title: { fontSize: 19, lineHeight: 25, color: '#FFF5DB', fontWeight: '800' },
  banner: { borderRadius: 18, overflow: 'hidden', borderWidth: 1, borderColor: '#557583' }, bannerShip: { position: 'absolute', width: '28%', height: '85%', left: '1%', top: '8%' }, bannerPlanet: { position: 'absolute', width: '30%', height: '95%', right: 0, top: '2%' }, bannerCopy: { position: 'absolute', left: '29%', right: '27%', top: 0, bottom: 0, justifyContent: 'center' }, bannerTitle: { color: '#FFF1CB', fontSize: 13, lineHeight: 19, fontWeight: '800', textAlign: 'center' }, label: { color: '#B4D8D5', fontSize: 11, letterSpacing: 1, fontWeight: '800' },
  modes: { flexShrink: 0 }, mode: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, borderWidth: 2, borderRadius: 17, gap: 9 }, modeIcon: { width: 42, height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center' }, modeCopy: { flex: 1, minWidth: 0, gap: 3 }, modeHeading: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', columnGap: 8 }, modeTitle: { color: '#FFF5DD', fontSize: 17, lineHeight: 22, fontWeight: '800' }, difficulty: { fontSize: 10, lineHeight: 14, fontWeight: '800' }, description: { color: '#D3E2E6', fontSize: 12, lineHeight: 17 }, count: { color: '#A6C3CF', fontSize: 10, lineHeight: 14 }, indicator: { width: 12, height: 12, borderRadius: 6, borderWidth: 2, borderColor: '#698393' },
  start: { minHeight: 54, backgroundColor: '#368C7B', borderWidth: 1, borderColor: '#A7DDC2', borderBottomWidth: 3 }, startText: { color: '#FFF5D9', fontSize: 18, fontWeight: '800', textAlign: 'center', padding: 10 }, continue: { minHeight: 48, borderWidth: 1, borderColor: '#526C83', backgroundColor: '#203A52' }, continueText: { fontSize: 12, color: '#D7E9EC', textAlign: 'center', padding: 8 }, footer: { color: '#ABC8CF', fontSize: 11, lineHeight: 16, textAlign: 'center' },
});
