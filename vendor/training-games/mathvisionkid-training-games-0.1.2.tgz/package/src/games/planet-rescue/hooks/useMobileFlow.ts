import { useEffect, useReducer, useRef } from 'react';
import { Card, cardAvailable, Event, RescueState } from '../logic/rescue';
import { closedFlow, mobileFlowReducer } from '../logic/mobileFlow';

export function useMobileFlow(state: RescueState, dispatch: (event: Event) => void, select: (card: Card) => void) {
  const [stored, send] = useReducer(mobileFlowReducer, state, closedFlow);
  const flow = stored.session === state.session && stored.index === state.index ? stored : closedFlow(state);
  const latest = useRef(state);
  const inputLock = useRef(false);
  const feedbackClock = useRef({ key: '', remaining: 0 });
  useEffect(() => { latest.current = state; }, [state]);
  useEffect(() => { inputLock.current = !!flow.pending; }, [flow.pending, flow.card, state.session, state.index]);
  const pending = flow.pending;
  const settled = !!pending && state.revision !== pending.before.revision;

  useEffect(() => {
    if (!pending || !settled || state.attack) return;
    const key = `${pending.before.session}:${pending.before.index}:${pending.before.revision}`;
    if (feedbackClock.current.key !== key) feedbackClock.current = { key, remaining: state.tone === 'success' ? 1100 : 260 };
    if (state.paused) return;
    const at = performance.now();
    const timer = setTimeout(() => send({ type: 'FEEDBACK_DONE', state: latest.current }), feedbackClock.current.remaining);
    return () => {
      clearTimeout(timer);
      feedbackClock.current.remaining = Math.max(0, feedbackClock.current.remaining - (performance.now() - at));
    };
  }, [pending, settled, state.paused, state.tone, state.attack]);

  const open = (card: Card) => {
    if (inputLock.current || flow.card || state.paused || !cardAvailable(state, card)) return;
    inputLock.current = true;
    send({ type: 'OPEN', state, card }); select(card);
  };
  const answer = (value: number) => {
    if (inputLock.current || !flow.card || state.paused || state.attack) return;
    inputLock.current = true;
    send({ type: 'SUBMIT', state, value });
    dispatch({ type: 'ANSWER', value, revision: state.revision });
  };
  return { flow, open, answer, back: () => send({ type: 'BACK' }), settled };
}
