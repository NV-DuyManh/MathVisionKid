import { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import { useTrainingServices, useTrainingSession } from '../../../shared/integration/context';
import { Card, createRun, Event, isTerminal, maxScore, Mode, RescueState, rescueReducer } from '../logic/rescue';
import { HIT_MS, METEOR_MS, SHOT_MS, TRAVEL_MS } from '../logic/planets';

type Command = Event | { type: 'START'; state: RescueState } | { type: 'DISCARD' };
const reducer = (s: RescueState, e: Command) => e.type === 'START' ? e.state : e.type === 'DISCARD' ? { ...createRun(), paused: true } : rescueReducer(s, e);
// Runs exist only in memory. History/settings remain in their existing stores.
let lastSession = 0;
const nextSession = () => { lastSession = Math.max(Date.now(), lastSession + 1); return lastSession; };

export function useRescue(enabled = false) {
  const { profileManager, profileId, soundManager } = useTrainingServices();
  const [state, rawDispatch] = useReducer(reducer, undefined, () => ({ ...createRun(), paused: true }));
  const [hasRun, setHasRun] = useState(false);
  const [storageError, setStorageError] = useState(false);
  const savedResults = useRef(new Set<number>());
  const lastSound = useRef('');
  const clock = useRef<{ at: number; session: number; revision: number } | null>(null);
  const flushTime = useCallback(() => {
    if (!clock.current) return;
    const now = performance.now(), segment = clock.current;
    const ms = now - segment.at;
    segment.at = now;
    rawDispatch({ type: 'TICK', ms, session: segment.session, revision: segment.revision });
  }, []);
  const dispatch = useCallback((event: Event) => {
    if (event.type !== 'TICK') flushTime();
    rawDispatch(event);
  }, [flushTime]);

  useEffect(() => {
    if (!enabled || !hasRun || state.paused || state.phase === 'won' || state.phase === 'lost') return;
    const segment = { at: performance.now(), session: state.session, revision: state.revision };
    clock.current = segment;
    const tick = () => { if (clock.current === segment) flushTime(); };
    // One authoritative clock; rendering interpolates these same segments.
    // Meteor gets a collision checkpoint and then an end checkpoint.
    const duration = state.attack ? (state.attack.hit ? METEOR_MS : HIT_MS) - state.attack.ms
      : state.phase === 'travelling' ? TRAVEL_MS - state.travelMs
      : state.phase === 'firing' ? SHOT_MS - state.shotMs : null;
    const timer = duration === null ? setInterval(tick, 1000) : setTimeout(tick, Math.max(1, Math.ceil(duration) + 1));
    return () => { clearTimeout(timer); clearInterval(timer); if (clock.current === segment) clock.current = null; };
  }, [enabled, hasRun, state.paused, state.phase, state.session, state.revision, state.attack, state.shotMs, state.travelMs, flushTime]);

  useEffect(() => {
    const pause = () => dispatch({ type: 'PAUSE', value: true });
    const sub = AppState.addEventListener('change', status => { if (status !== 'active') pause(); });
    if (Platform.OS === 'web' && typeof document !== 'undefined') {
      const visibility = () => { if (document.hidden) pause(); };
      document.addEventListener('visibilitychange', visibility);
      return () => { sub.remove(); document.removeEventListener('visibilitychange', visibility); };
    }
    return () => sub.remove();
  }, [dispatch]);

  useEffect(() => {
    if (!enabled || !hasRun) return;
    const key = `${state.session}:${state.revision}`;
    if (lastSound.current === key) return;
    lastSound.current = key;
    if (state.tone === 'error') soundManager.playIncorrect();
    else if (state.tone === 'success') soundManager.playCorrect();
  }, [enabled, hasRun, state.session, state.revision, state.tone, soundManager]);

  useEffect(() => {
    if (!hasRun || !isTerminal(state) || savedResults.current.has(state.session)) return;
    savedResults.current.add(state.session);
    if (state.phase === 'won') soundManager.playVictory();
    const now = Date.now();
    let alive = true;
    profileManager.saveSessionResult({
      sessionId: `pr-v3-${state.session}`, gameId: 'planet-rescue', profileId,
      difficulty: state.mode, startedAt: new Date(now - state.elapsed).toISOString(), completedAt: new Date(now).toISOString(),
      actualPlaytimeSeconds: Math.round(state.elapsed / 1000), isWon: state.phase === 'won',
      score: state.score, maxScore: maxScore(state), correctCount: state.correct, incorrectCount: state.incorrect,
      skillsPracticed: state.mode === 'easy' ? ['Rút gọn phân số', 'Làm quen quy đồng'] : ['Quy đồng mẫu số', 'So sánh phân số', ...(state.mode === 'hard' ? ['Cộng và rút gọn phân số'] : [])], schemaVersion: 1,
    }).catch(() => { if (alive) setStorageError(true); });
    return () => { alive = false; };
  }, [hasRun, state, profileManager, profileId, soundManager]);

  const start = useCallback((mode: Mode) => {
    clock.current = null;
    soundManager.playTap(); setHasRun(true); setStorageError(false);
    rawDispatch({ type: 'START', state: createRun(mode, nextSession()) });
  }, [soundManager]);
  const discard = useCallback(() => {
    clock.current = null; setHasRun(false); rawDispatch({ type: 'DISCARD' });
  }, []);
  const select = (card: Card) => { soundManager.playTap(); dispatch({ type: 'SELECT', card }); };
  useTrainingSession({ attemptId: String(state.session), started: hasRun, paused: state.paused, mode: state.mode, difficulty: state.mode,
    status: state.phase === 'won' ? 'won' : state.phase === 'lost' ? 'lost' : undefined,
    playtimeSeconds: state.elapsed / 1000, score: state.score, maxScore: maxScore(state), correctCount: state.correct, incorrectCount: state.incorrect,
    skillsPracticed: ['Phân số', 'Rút gọn', 'Quy đồng', 'So sánh phân số'] });
  return { state, dispatch, start, discard, select, loaded: true, storageError, hasRun };
}
