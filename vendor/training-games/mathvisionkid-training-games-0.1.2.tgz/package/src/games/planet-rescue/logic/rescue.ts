import { Fraction, gcd, lcm, simplifyFraction } from '../../../shared/math/fraction';

import { HIT_MS, METEOR_MS, PLANETS, PlanetId, SHOT_MS, TRAVEL_MS } from './planets';

export type Mode = 'easy' | 'medium' | 'hard';
export type Card = 'simplify' | 'common' | 'cannon';
export type Phase = 'reduce-first' | 'denominator' | 'numerator-a' | 'numerator-b' | 'compare' | 'sum' | 'reduce-sum' | 'ready' | 'firing' | 'travelling' | 'rescued' | 'won' | 'lost';
export interface Encounter {
  id: PlanetId;
  order: number;
  name: string;
  color: string;
  kind: 'reduce' | 'compare' | 'reduce-sync' | 'sync-sum';
  a: Fraction;
  b: Fraction;
}
export const MODES: Record<Mode, { title: string; subtitle: string; mission: string; count: number }> = {
  easy: { title: 'Khởi động', subtitle: 'Học cùng hoa tiêu', mission: 'Rút gọn nguồn pin để mở lồng năng lượng. Hai trạm làm quen với Quy Đồng. Tàu có 3 HP.', count: PLANETS.length },
  medium: { title: 'Rèn luyện', subtitle: 'Đồng bộ & so sánh', mission: 'Quy đồng hai nguồn pin, so sánh rồi chọn nguồn mạnh hơn để nạp pháo.', count: PLANETS.length },
  hard: { title: 'Thử thách', subtitle: 'Combo & thiên thạch', mission: 'Đọc giáp để chọn thứ tự thẻ. Mỗi 60 giây có thiên thạch; trả lời sai cũng bị tấn công. Tàu có 3 HP.', count: PLANETS.length },
};
const f = (num: number, den: number): Fraction => ({ num, den });

/** Seeded session content: no clock or random calls inside transitions. */
export function encounters(mode: Mode, seed = 1): Encounter[] {
  const offset = Math.abs(seed % 3);
  const easy = [[6, 8], [8, 12], [10, 15], [9, 12], [12, 18], [14, 21], [15, 20], [16, 24]];
  const pairs = [[1, 2, 2, 3], [2, 3, 3, 4], [3, 4, 4, 5], [2, 5, 1, 3], [5, 6, 3, 4], [3, 5, 2, 3]];
  return Array.from({ length: MODES[mode].count }, (_, i) => {
    let kind: Encounter['kind'] = 'reduce';
    let a = f(...easy[(i + offset) % easy.length] as [number, number]);
    let b = f(1, 2);
    if (mode !== 'easy' || i === 3 || i === 7) {
      const p = mode === 'easy' ? (i === 3 ? [1, 2, 1, 4] : [1, 3, 1, 6]) : pairs[(i + offset) % pairs.length];
      a = f(p[0], p[1]); b = f(p[2], p[3]); kind = 'compare';
      if (mode === 'hard') {
        kind = i % 2 === 0 ? 'reduce-sync' : 'sync-sum';
        if (kind === 'reduce-sync') a = f(a.num * (i === 4 ? 12 : 3), a.den * (i === 4 ? 12 : 3));
        // The sum is deliberately reducible, including improper fractions.
        else { a = f(i === 3 ? 2 : 1 + (i % 3), i === 3 ? 8 : 4); b = f(i === 3 ? 2 : 1 + (i % 3), i === 3 ? 12 : 6); }
      }
    }
    return { ...PLANETS[i], kind, a, b };
  });
}
export interface RescueState {
  version: 3;
  session: number;
  mode: Mode;
  rooms: Encounter[];
  index: number;
  phase: Phase;
  a: Fraction;
  b: Fraction;
  sum: Fraction | null;
  denominator: number | null;
  selected: Card;
  paused: boolean;
  hull: number;
  remaining: number;
  elapsed: number;
  shotMs: number;
  travelMs: number;
  attack: { id: number; ms: number; hit: boolean; source: 'answer' | 'deadline' } | null;
  score: number;
  correct: number;
  incorrect: number;
  revision: number;
  feedback: string;
  tone: 'info' | 'success' | 'error';
  history: string[];
}
export function initialPhase(room: Encounter): Phase {
  return room.kind === 'reduce' || room.kind === 'reduce-sync' ? 'reduce-first' : 'denominator';
}
export function cardFor(phase: Phase): Card {
  return phase === 'reduce-first' || phase === 'reduce-sum' ? 'simplify' : phase === 'ready' || phase === 'firing' || phase === 'rescued' || phase === 'won' ? 'cannon' : 'common';
}
export function createRun(mode: Mode = 'easy', session = 1): RescueState {
  const rooms = encounters(mode, session);
  const phase = initialPhase(rooms[0]);
  return { version: 3, session, mode, rooms, index: 0, phase, a: rooms[0].a, b: rooms[0].b,
    sum: null, denominator: null, selected: mode === 'hard' ? 'cannon' : cardFor(phase), paused: false, hull: 3,
    remaining: 60000, elapsed: 0, shotMs: 0, travelMs: 0, attack: null, score: 0, correct: 0, incorrect: 0, revision: 0,
    feedback: MODES[mode].mission, tone: 'info', history: [] };
}
export const fractionText = (value: Fraction) => `${value.num}/${value.den}`;
export const isTerminal = (s: RescueState) => s.phase === 'won' || s.phase === 'lost';
export function cardAvailable(s: RescueState, card: Card): boolean {
  if (isTerminal(s) || s.attack || s.phase === 'travelling' || s.phase === 'firing' || s.phase === 'rescued') return false;
  if (card === 'simplify') return s.phase === 'reduce-first' || s.phase === 'reduce-sum'
    || s.mode === 'hard' && s.phase === 'denominator' && gcd(s.a.num, s.a.den) > 1;
  if (card === 'common') return ['denominator', 'numerator-a', 'numerator-b', 'compare', 'sum'].includes(s.phase)
    || s.phase === 'reduce-first' && s.rooms[s.index].kind === 'sync-sum';
  return s.phase === 'ready';
}
export function cardReason(s: RescueState, card: Card): string {
  if (cardAvailable(s, card)) return card === 'simplify' ? 'Chia tử và mẫu cùng một số' : card === 'common' ? 'Đưa hai nguồn pin về cùng mẫu' : 'Đã nạp đầy · sẵn sàng bắn!';
  if (s.attack) return 'Đợi thiên thạch qua rồi thử lại';
  if (s.phase === 'travelling') return 'Đang bay tới hành tinh mới';
  if (s.phase === 'firing' || s.phase === 'rescued') return 'Đang giải cứu hành tinh';
  if (card === 'cannon') return 'Hoàn tất toán để mở khóa pháo';
  if (card === 'simplify') return s.rooms[s.index].kind === 'sync-sum' && !s.sum ? 'Ghép hai nguồn pin trước' : 'Không còn phân số cần rút gọn';
  return s.phase === 'reduce-first' ? 'Tinh lọc pin A trước khi đồng bộ' : 'Hai nguồn pin đã được xử lý';
}
export function expectedAnswer(s: RescueState): number | null {
  switch (s.phase) {
    case 'reduce-first': return gcd(s.a.num, s.a.den);
    case 'denominator': return lcm(s.a.den, s.b.den);
    case 'numerator-a': return s.a.num * (s.denominator! / s.a.den);
    case 'numerator-b': return s.b.num * (s.denominator! / s.b.den);
    case 'compare': return s.a.num >= s.b.num ? 0 : 1;
    case 'sum': return s.a.num + s.b.num;
    case 'reduce-sum': return gcd(s.sum!.num, s.sum!.den);
    default: return null;
  }
}
export function answerOptions(s: RescueState): number[] {
  if (s.phase === 'compare') return [0, 1];
  const answer = expectedAnswer(s);
  if (answer === null) return [];
  let pool: number[];
  if (s.phase === 'denominator') pool = [answer, s.a.den, s.b.den, answer * 2, Math.max(s.a.den, s.b.den) + 1];
  else if (s.phase.startsWith('reduce')) pool = [answer, 2, 3, 4, 5, 6, 7, 12];
  else pool = [answer, answer + 1, Math.max(1, answer - 1), answer + 3];
  const values = [...new Set(pool.filter(n => n > 1 || !s.phase.startsWith('reduce')))];
  const four = [answer, ...values.filter(n => n !== answer).slice(0, 3)];
  return four.sort((a, b) => ((a * 31 + s.index * 17) % 19) - ((b * 31 + s.index * 17) % 19));
}
export interface Prompt { label: string; title: string; hint: string }
export function prompt(s: RescueState): Prompt {
  switch (s.phase) {
    case 'reduce-first': return { label: 'THẺ RÚT GỌN', title: 'Tinh lọc nguồn pin A', hint: 'Chọn một số lớn hơn 1 chia hết cả tử và mẫu. Có thể rút gọn qua nhiều bước.' };
    case 'denominator': return { label: 'THẺ QUY ĐỒNG · 1/4', title: 'Tìm tần số chung', hint: 'Chọn mẫu chung nhỏ nhất: số nhỏ nhất chia hết cho cả hai mẫu. Mẫu chung khác vẫn đúng về toán, nhưng trạm này cần tần số nhỏ nhất.' };
    case 'numerator-a': return { label: 'THẺ QUY ĐỒNG · 2/4', title: 'Đồng bộ nguồn pin A', hint: `Mẫu A nhân ${s.denominator! / s.a.den}. Hãy nhân tử A với cùng số đó.` };
    case 'numerator-b': return { label: 'THẺ QUY ĐỒNG · 3/4', title: 'Đồng bộ nguồn pin B', hint: `Mẫu B nhân ${s.denominator! / s.b.den}. Hãy nhân tử B với cùng số đó.` };
    case 'compare': return { label: 'THẺ QUY ĐỒNG · 4/4', title: 'Nguồn pin nào mạnh hơn?', hint: 'Hai phân số đã cùng mẫu. Chọn nguồn có tử số lớn hơn để nạp pháo.' };
    case 'sum': return { label: 'THẺ QUY ĐỒNG · 4/4', title: 'Ghép năng lượng hai nguồn', hint: 'Cùng mẫu rồi! Cộng hai tử số và giữ nguyên mẫu. Sau đó tinh lọc pin đã ghép.' };
    case 'reduce-sum': return { label: 'THẺ RÚT GỌN · COMBO', title: 'Tinh lọc nguồn pin đã ghép', hint: 'Pin tổng chưa tối giản. Chia cả tử và mẫu cho cùng một ước chung để hoàn tất combo.' };
    case 'ready': return { label: 'PHÁO NĂNG LƯỢNG', title: 'Năng lượng đã sẵn sàng!', hint: 'Bắn vào máy tạo lồng để giải phóng hành tinh và các bạn nhỏ.' };
    case 'firing': return { label: 'ĐANG KHAI HỎA', title: 'Tia cứu hộ đang tới!', hint: 'Đạn năng lượng chỉ phá máy tạo lồng. Hành tinh được an toàn.' };
    case 'travelling': return { label: 'ĐANG DU HÀNH', title: `Tới ${s.rooms[s.index + 1]?.name ?? ''}`, hint: 'Phi thuyền đang bay tới hành tinh kế tiếp.' };
    case 'rescued': return { label: 'GIẢI CỨU THÀNH CÔNG', title: `${s.rooms[s.index].name} đã tự do!`, hint: 'Các cư dân đang gửi lời cảm ơn. Sẵn sàng tới hành tinh tiếp theo?' };
    default: return { label: 'KẾT THÚC HÀNH TRÌNH', title: s.phase === 'won' ? 'Tám hành tinh đã an toàn!' : 'Phi thuyền cần được sửa chữa!', hint: 'Em có thể bắt đầu lại một chuyến phiêu lưu mới.' };
  }
}
export type Event =
  | { type: 'SELECT'; card: Card }
  | { type: 'ANSWER'; value: number; revision: number }
  | { type: 'FIRE'; revision: number }
  | { type: 'TICK'; ms: number; session?: number; revision?: number }
  | { type: 'NEXT' }
  | { type: 'PAUSE'; value: boolean };
function correct(s: RescueState, changes: Partial<RescueState>, feedback: string, reward = 20): RescueState {
  const phase = changes.phase ?? s.phase;
  return { ...s, ...changes, selected: s.mode === 'hard' ? s.selected : cardFor(phase), correct: s.correct + 1, score: s.score + reward,
    revision: s.revision + 1, feedback, tone: 'success', history: [...s.history, feedback].slice(-6) };
}
function meteor(s: RescueState, source: 'answer' | 'deadline', feedback: string): RescueState {
  return { ...s, attack: { id: s.revision + 1, ms: 0, hit: false, source },
    incorrect: s.incorrect + (source === 'answer' ? 1 : 0),
    revision: s.revision + 1, tone: 'error', feedback };
}
function wrong(s: RescueState, feedback: string): RescueState { return meteor(s, 'answer', feedback); }
function arrive(s: RescueState): RescueState {
  const index = s.index + 1, room = s.rooms[index], phase = initialPhase(room);
  return { ...s, index, phase, a: room.a, b: room.b, sum: null, denominator: null,
    selected: s.mode === 'hard' ? 'cannon' : cardFor(phase),
    remaining: 60000, shotMs: 0, travelMs: 0, attack: null, history: [], revision: s.revision + 1, tone: 'info',
    feedback: room.kind === 'reduce-sync' ? 'Giáp lọc chặn tín hiệu: rút gọn pin A trước, rồi quy đồng hai nguồn.' : room.kind === 'sync-sum' ? 'Lồng đôi cần pin tổng: quy đồng, cộng năng lượng rồi rút gọn trước khi bắn.' : room.kind === 'compare' ? 'Hai nguồn pin khác mẫu. Dùng Quy Đồng để mở khóa máy tạo lồng.' : 'Rút gọn pin A để nạp năng lượng cứu hộ.' };
}
export function rescueReducer(s: RescueState, e: Event): RescueState {
  if (e.type === 'PAUSE') return { ...s, paused: e.value };
  if (s.paused || isTerminal(s)) return s;
  if (e.type === 'SELECT') {
    if (!cardAvailable(s, e.card)) return s;
    // Lồng đôi allows a real strategic choice: reduce A now for smaller common
    // denominators, or synchronize first and reduce the combined battery later.
    const phase = s.mode === 'hard' && s.phase === 'denominator' && e.card === 'simplify' ? 'reduce-first'
      : s.phase === 'reduce-first' && s.rooms[s.index].kind === 'sync-sum' && e.card === 'common' ? 'denominator' : s.phase;
    return { ...s, selected: e.card, phase, revision: phase === s.phase ? s.revision : s.revision + 1 };
  }
  if (e.type === 'TICK') {
    if (!Number.isFinite(e.ms) || e.ms <= 0 || e.session !== undefined && e.session !== s.session
      || e.revision !== undefined && e.revision !== s.revision) return s;
    const elapsed = s.elapsed + e.ms;
    if (s.attack) {
      const ms = Math.min(METEOR_MS, s.attack.ms + e.ms);
      const hit = s.attack.hit || ms >= HIT_MS;
      const hull = Math.max(0, s.hull - (!s.attack.hit && hit ? 1 : 0));
      return { ...s, elapsed, hull, attack: ms >= METEOR_MS ? null : { ...s.attack, ms, hit },
        phase: hull === 0 && ms >= METEOR_MS ? 'lost' : s.phase };
    }
    if (s.phase === 'travelling') {
      const travelMs = Math.min(TRAVEL_MS, s.travelMs + e.ms);
      return travelMs >= TRAVEL_MS ? arrive({ ...s, elapsed, travelMs }) : { ...s, elapsed, travelMs };
    }
    if (s.phase === 'firing') {
      const shotMs = Math.min(SHOT_MS, s.shotMs + e.ms);
      return { ...s, elapsed, shotMs, phase: shotMs >= SHOT_MS ? s.index === s.rooms.length - 1 ? 'won' : 'rescued' : 'firing' };
    }
    if (s.phase === 'rescued' || s.mode !== 'hard') return { ...s, elapsed };
    const remaining = s.remaining - e.ms;
    if (remaining > 0) return { ...s, elapsed, remaining };
    return meteor({ ...s, elapsed, remaining: 60000 }, 'deadline', 'Thiên thạch đang tới! Giữ nguyên bài toán, đợi tàu ổn định rồi tiếp tục nhé.');
  }
  if (e.type === 'NEXT') {
    if (s.attack || s.phase !== 'rescued' || s.index >= s.rooms.length - 1) return s;
    return { ...s, phase: 'travelling', travelMs: 0, shotMs: 0, revision: s.revision + 1,
      tone: 'info', feedback: `Tạm biệt ${s.rooms[s.index].name}! Đang bay tới ${s.rooms[s.index + 1].name}.` };
  }
  if (e.revision !== s.revision) return s;
  if (e.type === 'FIRE') {
    if (s.phase !== 'ready' || s.selected !== 'cannon') return s;
    return { ...s, phase: 'firing', shotMs: 0, score: s.score + 50, revision: s.revision + 1,
      feedback: 'Khai hỏa! Tia năng lượng đang phá máy tạo lồng.', tone: 'success' };
  }
  if (e.type !== 'ANSWER' || !Number.isSafeInteger(e.value) || !cardAvailable(s, s.selected) || s.selected !== cardFor(s.phase)) return s;
  const answer = expectedAnswer(s), v = e.value;
  if (answer === null) return s;
  if (s.phase === 'reduce-first' || s.phase === 'reduce-sum') {
    const source = s.phase === 'reduce-first' ? s.a : s.sum!;
    if (v <= 1 || source.num % v !== 0 || source.den % v !== 0) return wrong(s, `${v} chưa chia hết cả ${source.num} và ${source.den}. Giá trị phân số phải được giữ nguyên.`);
    const reduced = f(source.num / v, source.den / v);
    const done = gcd(reduced.num, reduced.den) === 1;
    const phase: Phase = done ? (s.phase === 'reduce-first' && s.rooms[s.index].kind !== 'reduce' ? 'denominator' : 'ready') : s.phase;
    return correct(s, { phase, ...(s.phase === 'reduce-first' ? { a: reduced } : { sum: reduced }) },
      `${fractionText(source)} → (${source.num} ÷ ${v})/(${source.den} ÷ ${v}) = ${fractionText(reduced)}. ${done ? phase === 'ready' ? 'Pin đã tinh lọc. Pháo được mở khóa!' : 'Pin A đã tối giản. Bây giờ hãy Quy Đồng.' : 'Đúng rồi! Phân số vẫn rút gọn tiếp được.'}`, done ? 20 : 0);
  }
  if (v !== answer) {
    const message = s.phase === 'denominator' && v % s.a.den === 0 && v % s.b.den === 0
      ? `${v} là mẫu chung hợp lệ, nhưng trạm yêu cầu mẫu chung nhỏ nhất. Tìm số nhỏ hơn chia hết cả hai mẫu nhé.`
      : s.phase === 'denominator' ? `${v} chưa chia hết cả hai mẫu ${s.a.den} và ${s.b.den}. Thử lại nhé.`
      : s.phase === 'compare' ? 'Cùng mẫu thì so sánh tử số. Chọn nguồn có tử lớn hơn nhé.'
      : s.phase === 'sum' ? 'Chỉ cộng hai tử số; mẫu số chung được giữ nguyên.' : 'Mẫu nhân bao nhiêu thì tử cũng nhân bấy nhiêu. Em thử lại nhé.';
    // A non-minimal common denominator is mathematically valid: explain without taking hull.
    if (s.phase === 'denominator' && v > 0 && v % s.a.den === 0 && v % s.b.den === 0) return { ...s, revision: s.revision + 1, feedback: message, tone: 'info' };
    return wrong(s, message);
  }
  if (s.phase === 'denominator') return correct(s, { denominator: v, phase: 'numerator-a' }, `Tần số chung là ${v}. Bây giờ nhân cả tử và mẫu của từng nguồn pin.`);
  if (s.phase === 'numerator-a' || s.phase === 'numerator-b') {
    const isA = s.phase === 'numerator-a', source = isA ? s.a : s.b, scaled = f(v, s.denominator!);
    return correct(s, { ...(isA ? { a: scaled } : { b: scaled }), phase: isA ? 'numerator-b' : s.rooms[s.index].kind === 'sync-sum' ? 'sum' : 'compare' },
      `${fractionText(source)} × ${scaled.den / source.den}/${scaled.den / source.den} = ${fractionText(scaled)}. ${isA ? 'Tiếp tục với pin B.' : 'Hai nguồn đã cùng mẫu! Lồng năng lượng mất lớp đồng bộ.'}`);
  }
  if (s.phase === 'sum') {
    const sum = f(v, s.denominator!);
    return correct(s, { sum, phase: gcd(sum.num, sum.den) > 1 ? 'reduce-sum' : 'ready' }, `${fractionText(s.a)} + ${fractionText(s.b)} = ${fractionText(sum)}. ${gcd(sum.num, sum.den) > 1 ? 'Dùng Rút Gọn để tinh lọc pin tổng.' : 'Pin tổng đã tối giản!'} `);
  }
  return correct(s, { phase: 'ready' }, `Pin ${v === 0 ? 'A' : 'B'} mạnh hơn vì ${Math.max(s.a.num, s.b.num)} > ${Math.min(s.a.num, s.b.num)}. Pháo đã nạp đủ năng lượng!`);
}
export function maxScore(s: RescueState): number {
  return s.rooms.reduce((total, room) => total + 50 + (room.kind === 'reduce' ? 20 : room.kind === 'compare' ? 80 : 100), 0);
}
export const reducedValue = (s: RescueState) => simplifyFraction(s.sum ?? s.a);
