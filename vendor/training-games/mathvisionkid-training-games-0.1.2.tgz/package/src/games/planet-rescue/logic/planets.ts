/** One shared itinerary for encounters, HUD and the existing cartoon renderer. */
export const PLANETS = [
  { id: 'mercury', name: 'Sao Thủy', color: '#B7B4B0', order: 1 },
  { id: 'venus', name: 'Sao Kim', color: '#EFB665', order: 2 },
  { id: 'earth', name: 'Trái Đất', color: '#62B9E8', order: 3 },
  { id: 'mars', name: 'Sao Hỏa', color: '#E58C70', order: 4 },
  { id: 'jupiter', name: 'Sao Mộc', color: '#E8BE96', order: 5 },
  { id: 'saturn', name: 'Sao Thổ', color: '#E8D092', order: 6 },
  { id: 'uranus', name: 'Sao Thiên Vương', color: '#92DEDF', order: 7 },
  { id: 'neptune', name: 'Sao Hải Vương', color: '#658DE2', order: 8 },
] as const;
export type PlanetId = typeof PLANETS[number]['id'];

export const SHOT_MS = 1100;
export const TRAVEL_MS = 1800;
export const METEOR_MS = 1000;
export const HIT_MS = 650;
