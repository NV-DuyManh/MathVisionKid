/** Layout coordinates only; never used to grade answers or advance a flight. */
export function mobileScene(width: number, height: number, hud: number, dock: number, labelSpace = 36) {
  const top = hud + 8;
  const available = Math.max(100, height - top - dock - 12);
  const planetY = Math.min(available * .1, 40);
  const planetSize = Math.min(width * .59, available - planetY - labelSpace);
  const shipWidth = Math.min(width * .46, (available - 40) * 250 / 170);
  const shipHeight = shipWidth * 170 / 250;
  const ship = { x: 4, y: Math.max(0, Math.min(available * .48, available - shipHeight - 40)), width: shipWidth, height: shipHeight };
  const planet = { x: width - planetSize - 6, y: planetY, width: planetSize, height: planetSize };
  return { top, height: available, ship, planet,
    launch: { x: ship.x + shipWidth * .89, y: ship.y + shipHeight * .53 },
    target: { x: planet.x + planetSize * 218 / 280, y: planet.y + planetSize * 49 / 280 },
  };
}
