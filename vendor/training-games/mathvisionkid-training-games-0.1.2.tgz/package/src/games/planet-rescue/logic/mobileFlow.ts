import { Card, cardAvailable, cardFor, isTerminal, RescueState } from './rescue';

/** Presentation only. Fractions, rewards, deadlines and card locks belong to rescueReducer. */
export interface MobileFlow {
  session: number;
  index: number;
  card: Card | null;
  canCancel: boolean;
  pending: { before: RescueState; value: number } | null;
}
export const closedFlow = (s: RescueState): MobileFlow => ({ session: s.session, index: s.index, card: null, canCancel: false, pending: null });
export type FlowEvent =
  | { type: 'OPEN'; state: RescueState; card: Card }
  | { type: 'BACK' }
  | { type: 'SUBMIT'; state: RescueState; value: number }
  | { type: 'FEEDBACK_DONE'; state: RescueState };

export function mobileFlowReducer(flow: MobileFlow, e: FlowEvent): MobileFlow {
  if (e.type === 'BACK') return flow.canCancel && !flow.pending ? { ...flow, card: null } : flow;
  const s = e.state;
  if (s.session !== flow.session || s.index !== flow.index) flow = closedFlow(s);
  if (s.paused || s.attack || s.phase === 'travelling' || isTerminal(s)) return flow;
  if (e.type === 'OPEN') {
    if (flow.card || flow.pending || !cardAvailable(s, e.card)) return flow;
    // SELECT can commit a different strategic phase in hard mode. No pretend undo.
    const changesPhase = s.mode === 'hard' && s.phase === 'denominator' && e.card === 'simplify'
      || s.phase === 'reduce-first' && s.rooms[s.index].kind === 'sync-sum' && e.card === 'common';
    return { ...flow, card: e.card, canCancel: !changesPhase, pending: null };
  }
  if (e.type === 'SUBMIT') {
    if (flow.pending || flow.card !== s.selected || s.selected !== cardFor(s.phase) || !cardAvailable(s, s.selected)) return flow;
    return { ...flow, canCancel: false, pending: { before: s, value: e.value } };
  }
  if (!flow.pending || s.revision === flow.pending.before.revision) return flow;
  // A wrong answer (including a valid non-minimal denominator) stays on this card.
  // A common-denominator card owns all its mathematical substeps, without reselection.
  // A meteor may replace the feedback tone after a correct answer. The actual
  // phase/card ownership, rather than that tone, decides which panel follows.
  const keep = cardFor(s.phase) === flow.card && cardAvailable(s, flow.card!);
  return { ...flow, card: keep ? flow.card : null, pending: null };
}
