import type { IStorageAdapter } from '../storage/storageAdapter';
import { isStudentUuid, isTrainingGameId, type TrainingGameId } from './contracts';

/** Immutable identity + game namespace, including late queued writes after unmount. */
export class ScopedGameStorage implements IStorageAdapter {
  readonly prefix: string;
  constructor(private readonly storage: IStorageAdapter, readonly studentId: string, readonly gameId: TrainingGameId) {
    if (!isStudentUuid(studentId) || !isTrainingGameId(gameId)) throw new Error('Invalid game storage identity');
    this.prefix = `@mathvisionkid:training:v1:${studentId.toLowerCase()}:${gameId}:`;
  }
  private key(key: string) { return this.prefix + encodeURIComponent(key); }
  getItem(key: string) { return this.storage.getItem(this.key(key)); }
  setItem(key: string, value: string) { return this.storage.setItem(this.key(key), value); }
  removeItem(key: string) { return this.storage.removeItem(this.key(key)); }
  async clear(): Promise<void> { throw new Error('Global clear is not supported for game storage'); }
}
