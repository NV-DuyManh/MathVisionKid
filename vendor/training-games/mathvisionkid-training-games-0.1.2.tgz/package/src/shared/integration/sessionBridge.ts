import { TRAINING_GAME_VERSION, type TrainingEvent, type TrainingGameId, type TrainingSessionResult, type TrainingSnapshot, type TrainingStatus } from './contracts';

/** One mounted game owns this bridge. It never reads a mutable current-account global. */
export class TrainingSessionBridge {
  private current: { snapshot: TrainingSnapshot; id: string; started: number; activeAt: number | null; activeMs: number; pauseCount: number; ended: boolean } | null = null;
  private disposed = false;
  private sequence = 0;
  constructor(private readonly options: {
    studentId: string; gameId: TrainingGameId; mountId: string;
    onResult: (result: TrainingSessionResult) => void;
    onEvent?: (event: TrainingEvent) => void;
    now?: () => number;
  }) {}
  private now() { return this.options.now?.() ?? Date.now(); }
  private event(type: TrainingEvent['type']) {
    if (!this.current) return;
    this.options.onEvent?.({ schemaVersion: 1, eventId: `${this.current.id}:event:${++this.sequence}`, sessionId: this.current.id, studentId: this.options.studentId, gameId: this.options.gameId, at: new Date(this.now()).toISOString(), type });
  }
  observe(snapshot: TrainingSnapshot) {
    if (this.disposed) return;
    if (!snapshot.started) { if (this.current && !this.current.ended) this.finish('abandoned'); return; }
    if (this.current?.snapshot.attemptId !== snapshot.attemptId) {
      if (this.current && !this.current.ended) this.finish('restarted');
      this.current = { snapshot, id: `${this.options.mountId}:${snapshot.attemptId}`, started: this.now(), activeAt: snapshot.paused ? null : this.now(), activeMs: 0, pauseCount: 0, ended: false };
      this.event('started');
    }
    const current = this.current!;
    if (current.ended) return;
    if (current.snapshot.paused !== snapshot.paused) {
      if (snapshot.paused) {
        if (current.activeAt !== null) current.activeMs += this.now() - current.activeAt;
        current.activeAt = null; current.pauseCount++; this.event('paused');
      } else { current.activeAt = this.now(); this.event('resumed'); }
    }
    current.snapshot = snapshot;
    if (snapshot.status) this.finish(snapshot.status);
  }
  private finish(status: TrainingStatus) {
    const current = this.current;
    if (!current || current.ended) return;
    current.ended = true;
    const { snapshot } = current;
    const measured = (current.activeMs + (current.activeAt === null ? 0 : this.now() - current.activeAt)) / 1000;
    this.event('finished');
    this.options.onResult({ schemaVersion: 1, eventId: `${current.id}:result:v1`, sessionId: current.id, studentId: this.options.studentId, gameId: this.options.gameId, gameVersion: TRAINING_GAME_VERSION,
      mode: snapshot.mode, difficulty: snapshot.difficulty, startedAt: new Date(current.started).toISOString(), completedAt: new Date(this.now()).toISOString(),
      playtimeSeconds: Math.max(0, snapshot.playtimeSeconds ?? measured), status,
      score: snapshot.score, maxScore: snapshot.maxScore, correctCount: snapshot.correctCount, incorrectCount: snapshot.incorrectCount,
      skillsPracticed: [...snapshot.skillsPracticed], pauseCount: current.pauseCount, syncStatus: 'local-only' });
  }
  dispose() { if (this.disposed) return; this.finish('abandoned'); this.disposed = true; }
}
