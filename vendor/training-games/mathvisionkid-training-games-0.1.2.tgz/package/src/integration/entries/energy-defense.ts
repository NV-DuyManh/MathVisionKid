export { EnergyDefenseScreen as default } from '../../games/energy-defense';
