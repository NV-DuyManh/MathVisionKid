export { BlockIslandScreen as default } from '../../games/block-island';
