export { PlanetRescueScreen as default } from '../../games/planet-rescue';
