export { RaceToFinishScreen as default } from '../../games/race-to-finish';
