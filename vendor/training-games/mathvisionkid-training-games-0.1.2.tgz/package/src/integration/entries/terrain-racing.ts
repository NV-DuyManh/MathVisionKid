export { TerrainRacingScreen as default } from '../../games/terrain-racing';
