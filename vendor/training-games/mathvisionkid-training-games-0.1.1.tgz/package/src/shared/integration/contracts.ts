export const TRAINING_GAME_IDS = ['planet-rescue', 'race-to-finish', 'terrain-racing', 'energy-defense', 'block-island'] as const;
export type TrainingGameId = typeof TRAINING_GAME_IDS[number];
export const TRAINING_GAME_VERSION = '0.1.1';
export const RESULT_SCHEMA_VERSION = 1;
export type TrainingStatus = 'won' | 'lost' | 'abandoned' | 'restarted';
export interface TrainingSnapshot {
  attemptId: string;
  started: boolean;
  paused: boolean;
  mode: string;
  difficulty?: string;
  status?: 'won' | 'lost' | 'abandoned';
  playtimeSeconds?: number;
  score?: number;
  maxScore?: number;
  correctCount?: number;
  incorrectCount?: number;
  skillsPracticed: string[];
}
export interface TrainingSessionResult {
  schemaVersion: 1;
  eventId: string;
  sessionId: string;
  studentId: string;
  gameId: TrainingGameId;
  gameVersion: string;
  mode: string;
  difficulty?: string;
  startedAt: string;
  completedAt: string;
  playtimeSeconds: number;
  status: TrainingStatus;
  score?: number;
  maxScore?: number;
  correctCount?: number;
  incorrectCount?: number;
  skillsPracticed: string[];
  pauseCount: number;
  syncStatus: 'local-only';
}
export type TrainingEvent = { schemaVersion: 1; eventId: string; sessionId: string; gameId: TrainingGameId; studentId: string; at: string; type: 'started' | 'paused' | 'resumed' | 'finished' };
export const isStudentUuid = (value: unknown): value is string => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
export const isTrainingGameId = (value: unknown): value is TrainingGameId => typeof value === 'string' && (TRAINING_GAME_IDS as readonly string[]).includes(value);
