import { createContext, useContext, useLayoutEffect } from 'react';
import { profileManager as standaloneProfileManager, type ProfileManager } from '../storage/profileManager';
import { questionHistory as standaloneQuestionHistory, type QuestionHistory } from '../math/questionHistory';
import { soundManager as standaloneSoundManager, type AudioController } from '../audio/audioController';
import type { IStorageAdapter } from '../storage/storageAdapter';
import type { TrainingSessionBridge } from './sessionBridge';
import type { TrainingSnapshot } from './contracts';

export interface TrainingServices {
  profileId: string;
  profileManager: ProfileManager;
  questionHistory: QuestionHistory;
  soundManager: AudioController;
  storage: IStorageAdapter;
  bridge: TrainingSessionBridge;
  registerBack: (handler: () => void) => () => void;
}
export const TrainingServicesContext = createContext<TrainingServices | null>(null);
const standalone = { profileId: 'local-learner-sandbox-01', profileManager: standaloneProfileManager, questionHistory: standaloneQuestionHistory, soundManager: standaloneSoundManager };
export function useTrainingServices() { return useContext(TrainingServicesContext) ?? standalone; }
export function useTrainingSession(snapshot: TrainingSnapshot) {
  const services = useContext(TrainingServicesContext);
  useLayoutEffect(() => { services?.bridge.observe(snapshot); }, [services, snapshot]);
}
export function useTrainingBack(handler: () => void) {
  const services = useContext(TrainingServicesContext);
  useLayoutEffect(() => services?.registerBack(handler), [services, handler]);
}
export function useEmbeddedTraining() { return useContext(TrainingServicesContext); }
