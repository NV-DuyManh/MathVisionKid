import React, { useId } from 'react';
import Svg, { Circle, Defs, G, LinearGradient, Path, Stop } from 'react-native-svg';

// A right-handed cube: opposite faces always sum to seven.
const ADJACENT: Record<number, [number, number]> = {
  1: [2, 3], 2: [6, 3], 3: [2, 6], 4: [2, 1], 5: [1, 3], 6: [5, 3],
};
const PIPS: Record<number, [number, number][]> = {
  1: [[35, 35]],
  2: [[17, 17], [53, 53]],
  3: [[17, 17], [35, 35], [53, 53]],
  4: [[17, 17], [53, 17], [17, 53], [53, 53]],
  5: [[17, 17], [53, 17], [35, 35], [17, 53], [53, 53]],
  6: [[17, 16], [53, 16], [17, 35], [53, 35], [17, 54], [53, 54]],
};

function Pips({ value, transform, front = false }: { value: number; transform: string; front?: boolean }) {
  return <G transform={transform} testID={front ? `dice-front-${value}` : undefined}>
    {PIPS[value].map(([x,y], index) => <G key={index}>
      <Circle cx={x} cy={y} r="5.8" fill="#A49AB5" />
      <Circle cx={x} cy={y + .8} r="4.7" fill="#302940" testID={front ? 'dice-front-pip' : undefined} />
      <Path d={`M${x-3.2} ${y+2.8}q3.2 2.4 6.4 0`} fill="none" stroke="#F7F2FF" strokeOpacity=".45" strokeWidth=".8" />
    </G>)}
  </G>;
}

/** Three shaded planes, with recessed pips; the controller supplies the front value. */
export function DiceModel({ value }: { value: number }) {
  const id = useId().replace(/:/g, '');
  const [top, right] = ADJACENT[value];
  return <Svg width="100%" height="100%" viewBox="0 0 180 180" accessible={false}>
    <Defs>
      <LinearGradient id={`${id}front`} x1="0" y1="0" x2=".8" y2="1"><Stop offset="0" stopColor="#FFFEF7"/><Stop offset="1" stopColor="#E5DDEE"/></LinearGradient>
      <LinearGradient id={`${id}right`} x1="0" y1="0" x2="1" y2=".6"><Stop offset="0" stopColor="#CCC1DF"/><Stop offset="1" stopColor="#AAA0C0"/></LinearGradient>
      <LinearGradient id={`${id}top`} x1="0" y1="0" x2="1" y2="1"><Stop offset="0" stopColor="#FFFFFF"/><Stop offset="1" stopColor="#F1ECFA"/></LinearGradient>
    </Defs>
    <Path d="M31 55 94 70Q98 71 98 77V139Q98 145 92 144L32 130Q26 129 26 122V62Q26 54 31 55Z" fill={`url(#${id}front)`} stroke="#92859F" strokeWidth="1.2"/>
    <Path d="M98 75Q98 71 103 68L144 45Q150 42 150 49V110Q150 116 145 119L103 144Q98 147 98 140Z" fill={`url(#${id}right)`} stroke="#8F829F" strokeWidth="1.2"/>
    <Path d="M31 54 73 29Q78 26 84 28L145 42Q151 44 145 48L103 72Q98 75 92 73L31 59Q25 57 31 54Z" fill={`url(#${id}top)`} stroke="#BBB0CC" strokeWidth="1.2"/>
    <Path d="m34 62 55 13q3 1 3 5v55M104 79l37-22" fill="none" stroke="#FFFFFF" strokeOpacity=".65" strokeWidth="2" strokeLinecap="round"/>
    <Pips value={top} transform="matrix(0.89 0.21 0.60 -0.35 36 55)" />
    <Pips value={right} transform="matrix(0.65 -0.38 0 0.92 102 76)" />
    <Pips value={value} transform="matrix(0.89 0.21 0 0.92 32 61)" front />
  </Svg>;
}
