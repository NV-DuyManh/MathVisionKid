import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, useFrameCallback } from 'react-native-reanimated';
import { DiceModel } from './DiceModel';
import { DICE_ROLL_DURATION_MS } from '../state/turnTiming';

function Face({ value, result, elapsed, reduced }: { value: number; result: number; elapsed: ReturnType<typeof useSharedValue<number>>; reduced: boolean }) {
  const style = useAnimatedStyle(() => ({ opacity: (elapsed.value >= 500 || reduced ? result : Math.floor(elapsed.value / 65) % 6 + 1) === value ? 1 : 0 }));
  return <Animated.View testID={`dice-model-${value}`} style={[StyleSheet.absoluteFill, style]}>
    <DiceModel value={value} />
  </Animated.View>;
}
export function DiceOverlay({ value, paused, reduced, getRemaining }: { value: number; paused: boolean; reduced: boolean; getRemaining: () => number }) {
  const elapsed = useSharedValue(0);
  const frozen = useSharedValue(paused);
  useEffect(() => { frozen.set(paused); elapsed.set(DICE_ROLL_DURATION_MS - getRemaining()); }, [paused, frozen, elapsed, getRemaining]);
  useFrameCallback(frame => {
    if (!frozen.value && elapsed.value < DICE_ROLL_DURATION_MS) elapsed.set(Math.min(DICE_ROLL_DURATION_MS, elapsed.value + Math.max(frame.timeSincePreviousFrame ?? 0, 0)));
  });
  const style = useAnimatedStyle(() => {
    const t = Math.min(1, elapsed.value / 500);
    const bounce = reduced ? 0 : Math.sin(t * Math.PI);
    const landing = reduced || t < .72 ? 0 : Math.sin((t - .72) / .28 * Math.PI);
    return { transform: [{ perspective: 650 }, { translateY: -bounce * 44 - landing * 7 }, { translateX: bounce * 12 }, { scale: 1 + bounce * .08 },
      { rotateX: `${reduced ? 0 : Math.sin(t * Math.PI * 2) * 22}deg` }, { rotateY: `${reduced ? 0 : Math.cos(t * Math.PI * 2) * (1-t) * 28}deg` },
      { rotateZ: `${reduced ? 0 : (1 - t) * 270}deg` }] };
  });
  const shadowStyle = useAnimatedStyle(() => {
    const lift = reduced ? 0 : Math.sin(Math.min(1, elapsed.value / 500) * Math.PI);
    return { opacity: .22 - lift * .12, transform: [{ scaleX: 1 - lift * .25 }, { scaleY: 1 - lift * .3 }] };
  });
  const labelStyle = useAnimatedStyle(() => ({ opacity: elapsed.value >= 500 || reduced ? 1 : 0 }));
  return <View pointerEvents="none" testID="dice-overlay" style={styles.overlay}>
    <View style={styles.stage}>
    <Animated.View testID="dice-contact-shadow" style={[styles.shadow, shadowStyle]} />
    <Animated.View testID="rolling-dice" style={[styles.die, style]}>
      {[1, 2, 3, 4, 5, 6].map(face => <Face key={face} value={face} result={value} elapsed={elapsed} reduced={reduced} />)}
    </Animated.View>
    </View>
    <Animated.View style={labelStyle}><Text testID="dice-result" style={styles.result}>Tung được {value}</Text></Animated.View>
  </View>;
}
const styles = StyleSheet.create({ overlay: { position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(24,22,76,.24)' },
  stage: { width: 190, height: 184 },
  shadow: { position: 'absolute', width: 108, height: 17, borderRadius: 60, backgroundColor: '#181024', left: 44, bottom: 17 },
  die: { width: 190, height: 184 },
  result: { marginTop: 6, paddingHorizontal: 20, paddingVertical: 9, borderWidth: 1, borderColor: '#DBCDA4',
    backgroundColor: '#FFFAE9', borderRadius: 14, fontSize: 22, fontWeight: '900', color: '#392957' } });
