export const SHORTCUT_ENTRY_PAUSE_MS = 450;
export const QUESTION_TIME_LIMIT_MS = 30_000;
// 500 ms to settle, then two seconds to read the result before the question.
export const DICE_ROLL_DURATION_MS = 2_500;
export const BOT_ANSWER_DELAY_MS = 10_000;
export const MYSTERY_RESULT_DISPLAY_MS = 1_400;
export const CLEANSE_CHOICE_MS = 5_000;
